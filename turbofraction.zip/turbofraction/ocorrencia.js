/*
 * TurboFraction — tela de Ocorrência (/FractionWeb/pages/ocorrencia/ocorrencia.jad)
 * Quando aberta pelo botão "Gerar ocorrência" (em aba nova ou no cartão da consulta):
 *   1. preenche a remessa;
 *   2. escolhe "ENTREGA" na lista OCORRÊNCIA (o site então carrega a lista de detalhes).
 * O detalhe e o "Processar" ficam com o usuário.
 */
(() => {
  'use strict';
  const m = /tf_remessa=(\d{6,})/.exec(location.hash);
  if (!m) return;
  const remessa = m[1];
  const noCartao = /tf_cartao=1/.test(location.hash);
  // Limpa o hash para não repreencher se a página for recarregada.
  history.replaceState(null, '', location.pathname + location.search);
  if (noCartao) document.documentElement.classList.add('tf-no-cartao');

  const esperar = ms => new Promise(r => setTimeout(r, ms));
  async function esperarElemento(id, limite = 10000) {
    const ini = Date.now();
    while (Date.now() - ini < limite) {
      const el = document.getElementById(id);
      if (el) return el;
      await esperar(200);
    }
    return null;
  }

  function definir(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  const clicar = el => el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));

  const clicarComo = el => ['mousedown', 'mouseup', 'click'].forEach(t => el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));

  /**
   * Escolhe uma opção de um menu do PrimeFaces: primeiro como o usuário (abre o menu e clica no item);
   * se o menu não aceitar o clique (acontece dentro do cartão da consulta), escolhe direto na lista
   * escondida do formulário, que dispara o mesmo carregamento dos detalhes, e fecha o menu.
   */
  async function escolherNoMenu(base, rotulo) {
    const sel = document.getElementById(base + '_input');
    const label = document.getElementById(base + '_label');
    const painel = document.getElementById(base + '_panel');
    if (!sel || !label) return false;
    const escolhido = () => (label.textContent || '').trim().toUpperCase() === rotulo;
    if (escolhido()) return true;
    const item = painel && [...painel.querySelectorAll('li')].find(li => (li.getAttribute('data-label') || li.textContent || '').trim().toUpperCase() === rotulo);
    if (item) {
      clicar(label);         // abre o menu
      await esperar(400);
      clicarComo(item);      // escolhe o item
      await esperar(400);
      if (escolhido()) return true;
    }
    // Plano B: a lista <select> escondida (o onchange do site carrega os detalhes).
    const opt = [...sel.options].find(o => o.text.trim().toUpperCase() === rotulo);
    if (!opt) return false;
    sel.value = opt.value;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    label.textContent = opt.text;
    if (painel) {
      painel.querySelectorAll('li').forEach(li => li.classList.toggle('ui-state-highlight', li === item));
      painel.style.display = 'none';
    }
    document.getElementById(base)?.classList.remove('ui-state-focus');
    await esperar(300);
    return escolhido();
  }

  /* No cartão da consulta: quando o Fraction confirma a ocorrência, avisa a consulta (que fecha o cartão e se atualiza). */
  if (noCartao && window.parent !== window) {
    let aguardando = 0;
    document.addEventListener('click', ev => {
      const b = ev.target.closest && ev.target.closest('button');
      if (b && /processar/i.test(b.textContent || '')) aguardando = Date.now();
    }, true);
    const vistos = new WeakSet();
    new MutationObserver(() => {
      if (!aguardando || Date.now() - aguardando > 60000) return;
      const itens = document.querySelectorAll('[id^="form_notificacao:mensagem"] .ui-growl-item-container');
      for (const it of itens) {
        if (vistos.has(it) || /Coleta/i.test(it.querySelector('.ui-growl-title')?.textContent || '')) continue;
        vistos.add(it);
        const erro = it.querySelector('.ui-growl-image-error, .ui-growl-image-fatal, .ui-growl-image-warn') || /ui-growl-(error|fatal|warn)/.test(it.className);
        if (erro) { aguardando = 0; return; } // o usuário vê o erro e corrige no próprio cartão
        if (it.querySelector('.ui-growl-image-info') || /ui-growl-info/.test(it.className)) {
          aguardando = 0;
          const msg = (it.querySelector('.ui-growl-title')?.textContent || '').trim();
          window.parent.postMessage({ tipo: 'tf-ocorrencia-ok', remessa, msg }, location.origin);
          return;
        }
      }
    }).observe(document.body, { childList: true, subtree: true });
  }

  (async () => {
    const campo = await esperarElemento('form_ocorrencia:id_remessa');
    if (!campo) return;
    campo.focus();
    definir(campo, remessa);
    await esperar(800); // validação da remessa pelo site

    const ok = await escolherNoMenu('form_ocorrencia:selectOcorrencia', 'ENTREGA');
    if (!ok) console.info('[TurboFraction] não consegui escolher ENTREGA automaticamente');

    // Deixa a lista de detalhes à vista para o usuário escolher.
    await esperar(1200);
    const det = document.getElementById('form_ocorrencia:selectDetalhe') || document.getElementById('form_ocorrencia');
    if (det) det.scrollIntoView({ block: 'center' });
  })();
})();
