/*
 * TurboFraction — Conferência de manifesto (/FractionWeb/pages/conferenciaManifesto/confere.jad)
 * Botão "Faltantes por Circuit": gera os relatórios de inconsistência do próprio Fraction
 * (o mesmo clique dos ícones Excel e PDF), recebe o .csv e o .pdf direto (sem ir para Downloads)
 * e abre um painel com as remessas faltantes agrupadas por Circuit.
 * Circuit, peso e bairro/cidade vêm do arquivo da Performance guardado pelo Painel de Pendências.
 */
(() => {
  'use strict';
  const FORM = 'form_conferencia_manifesto';
  const CAB_AJAX = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Faces-Request': 'partial/ajax',
    'X-Requested-With': 'XMLHttpRequest',
  };

  function campos(form) {
    const p = new URLSearchParams();
    form.querySelectorAll('input[name], select[name], textarea[name]').forEach(el => {
      if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
      if (el.type === 'submit' || el.type === 'button') return;
      if (el.tagName === 'SELECT' && el.multiple) { [...el.selectedOptions].forEach(o => p.append(el.name, o.value)); return; }
      p.append(el.name, el.value);
    });
    return p;
  }

  function atualizarViewState(xml) {
    const m = /<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[([^\]]*)\]\]>/.exec(xml);
    if (m) document.querySelectorAll('input[name="javax.faces.ViewState"]').forEach(i => { i.value = m[1]; });
  }

  /** Repete o clique no ícone (excel|pdf) e devolve o arquivo gerado pelo Fraction. */
  async function baixar(tipo) {
    const form = document.getElementById(FORM);
    const link = document.getElementById(`${FORM}:id_exportar_${tipo}`);
    const botao = document.getElementById(`${FORM}:id_exportar_${tipo}_button`);
    if (!form || !link || !botao) throw new Error('não encontrei os ícones de exportação na tela');
    const acao = form.getAttribute('action') || location.href;
    const p1 = new URLSearchParams({
      'javax.faces.partial.ajax': 'true',
      'javax.faces.source': link.id,
      'javax.faces.partial.execute': '@all',
      'javax.faces.partial.render': 'form_notificacao:mensagemTmp',
      [link.id]: link.id,
    });
    campos(form).forEach((v, k) => p1.append(k, v));
    const r1 = await fetch(acao, { method: 'POST', credentials: 'same-origin', headers: CAB_AJAX, body: p1.toString() });
    const x1 = await r1.text();
    atualizarViewState(x1);
    const args = /<extension[^>]*type="args"[^>]*>([\s\S]*?)<\/extension>/.exec(x1);
    if (args && /"existeDado"\s*:\s*false/.test(args[1])) throw new Error('não há inconsistências para exportar (adicione os manifestos primeiro)');
    const p2 = campos(form);
    p2.set(FORM, FORM);
    p2.set(botao.name, botao.value || '');
    const r2 = await fetch(acao, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: p2.toString(),
    });
    const ct = r2.headers.get('content-type') || '';
    if (/text\/html|xml/i.test(ct)) throw new Error('o Fraction respondeu com uma página em vez do arquivo');
    const nome = (/filename="?([^";]+)/i.exec(r2.headers.get('content-disposition') || '') || [])[1] || `InconsistenciaManifesto.${tipo === 'pdf' ? 'pdf' : 'csv'}`;
    return { buffer: await r2.arrayBuffer(), nome };
  }

  /* ---------- Painel por cima da página (mesmo do Painel de Pendências) ---------- */
  function abrirPainel() {
    document.getElementById('tf-painel')?.remove();
    const fundo = document.createElement('div');
    fundo.id = 'tf-painel';
    fundo.innerHTML = '<div class="tf-painel-caixa"><button type="button" class="tf-painel-fechar" title="Fechar (Esc)">✕</button><iframe class="tf-painel-quadro" allow="clipboard-write"></iframe></div>';
    const quadro = fundo.querySelector('iframe');
    quadro.src = chrome.runtime.getURL('relatorio.html#faltantes');
    const fechar = () => { fundo.remove(); document.removeEventListener('keydown', esc); };
    const esc = ev => { if (ev.key === 'Escape') fechar(); };
    fundo.querySelector('.tf-painel-fechar').addEventListener('click', fechar);
    document.addEventListener('keydown', esc);
    document.body.appendChild(fundo);
    quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; }, { once: true });
    return quadro;
  }
  function enviar(quadro, msg, transferir) {
    const destino = new URL(chrome.runtime.getURL('')).origin;
    const mandar = () => quadro.contentWindow.postMessage(Object.assign({ origem: location.origin }, msg), destino, transferir || []);
    if (quadro.dataset.pronto) mandar(); else quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; mandar(); }, { once: true });
  }
  const deBase64 = b64 => { const s = atob(b64), u8 = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i); return u8.buffer; };

  async function gerar(btn) {
    const quadro = abrirPainel();
    btn.disabled = true;
    try {
      enviar(quadro, { tipo: 'tf-status', texto: 'Gerando o relatório de inconsistências no Fraction…' });
      const csv = await baixar('excel');
      enviar(quadro, { tipo: 'tf-status', texto: 'Gerando o PDF original…' });
      let pdf = null;
      try { pdf = await baixar('pdf'); } catch (e) { console.warn('[TurboFraction] PDF', e); }
      // Arquivo da Performance guardado (Circuit, peso, bairro/cidade)
      let perf = null;
      try {
        const c = (await chrome.storage.local.get('tf_cache_performance')).tf_cache_performance;
        if (c && c.b64) perf = { buffer: deBase64(c.b64), nome: c.nome, quando: c.quando };
      } catch (e) { /* sem arquivo guardado */ }
      const transf = [csv.buffer];
      if (pdf) transf.push(pdf.buffer);
      if (perf) transf.push(perf.buffer);
      enviar(quadro, { tipo: 'tf-faltantes', csv, pdf, perf }, transf);
    } catch (e) {
      console.warn('[TurboFraction]', e);
      enviar(quadro, { tipo: 'tf-status', erro: true, texto: 'Não consegui gerar o relatório: ' + e.message + '.' });
    } finally {
      btn.disabled = false;
    }
  }

  function colocarBotao() {
    if (document.getElementById('tf-faltantes')) return;
    const excel = document.getElementById(`${FORM}:id_exportar_excel`);
    if (!excel) return;
    const btn = document.createElement('button');
    btn.id = 'tf-faltantes';
    btn.type = 'button';
    btn.className = 'tf-pend-botao';
    btn.textContent = '📦 Faltantes por Circuit';
    btn.title = 'Gera o relatório de inconsistências e mostra as remessas faltantes agrupadas por Circuit';
    btn.addEventListener('click', () => gerar(btn));
    const alvo = excel.closest('table') || excel.parentElement;
    alvo.parentElement.insertBefore(btn, alvo);
  }

  try { chrome.storage.local.set({ tf_origem: location.origin }); } catch (e) { /* ok */ }
  colocarBotao();
  let ag = 0;
  new MutationObserver(() => { if (!ag) ag = requestAnimationFrame(() => { ag = 0; colocarBotao(); }); })
    .observe(document.body, { childList: true, subtree: true });
})();
