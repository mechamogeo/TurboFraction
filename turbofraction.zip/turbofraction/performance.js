/*
 * TurboFraction — Performance de Entrega (/FractionWeb/jad/performance_entrega)
 * Na tela de resultado, o botão "📊 Painel de Pendências" gera o mesmo arquivo do clique
 * no total do período, recebe o .zip direto (sem ir para a pasta Downloads) e abre
 * o painel (tabela Status × Descrição) por cima da página.
 * O arquivo fica guardado na extensão e é reaproveitado até o próximo horário de
 * atualização do Fraction (06h24, 08h24, 10h24 …), sem gerar de novo.
 */
(() => {
  'use strict';
  const FORM = 'formTreeTotal';

  const CAB_AJAX = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Faces-Request': 'partial/ajax',
    'X-Requested-With': 'XMLHttpRequest',
  };

  function campos(form) {
    const p = new URLSearchParams();
    form.querySelectorAll('input[name], select[name], textarea[name]').forEach(el => {
      if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
      if (el.type === 'submit' || el.type === 'button') return;
      p.append(el.name, el.value);
    });
    return p;
  }

  function atualizarViewState(xml) {
    const m = /<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[([^\]]*)\]\]>/.exec(xml);
    if (m) document.querySelectorAll('input[name="javax.faces.ViewState"]').forEach(i => { i.value = m[1]; });
  }

  /** Repete o clique no total do período e devolve o arquivo (.zip) como ArrayBuffer. */
  async function baixarArquivo() {
    const form = document.getElementById(FORM);
    const corpo = document.getElementById(FORM + ':idTreeTotal_data');
    const link = corpo && corpo.querySelector('tr a.ui-commandlink');
    const botao = link && link.parentElement.querySelector('button[name]');
    if (!form || !link || !botao) throw new Error('Não encontrei o total do período na tela');
    const acao = form.getAttribute('action') || location.href;

    // 1) Prepara o arquivo (o mesmo pedido do clique no número).
    const p1 = new URLSearchParams({
      'javax.faces.partial.ajax': 'true',
      'javax.faces.source': link.id,
      'javax.faces.partial.execute': '@all',
      'javax.faces.partial.render': 'form_notificacao:mensagemTmp',
      [link.id]: link.id,
    });
    campos(form).forEach((v, k) => p1.set(k, v));
    const r1 = await fetch(acao, { method: 'POST', credentials: 'same-origin', headers: CAB_AJAX, body: p1.toString() });
    const x1 = await r1.text();
    atualizarViewState(x1);
    const args = /<extension[^>]*type="args"[^>]*>([\s\S]*?)<\/extension>/.exec(x1);
    if (args && /"ok"\s*:\s*false/.test(args[1])) throw new Error('O Fraction não gerou o arquivo (tente o clique manual no total)');

    // 2) Baixa o arquivo (o mesmo envio do botão oculto do site).
    const p2 = campos(form);
    p2.set(FORM, FORM);
    p2.set(botao.name, botao.value || '');
    const r2 = await fetch(acao, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: p2.toString(),
    });
    const tipo = r2.headers.get('content-type') || '';
    if (/text\/html|xml/i.test(tipo)) throw new Error('O Fraction respondeu com uma página em vez do arquivo');
    const nome = (/filename="?([^";]+)/i.exec(r2.headers.get('content-disposition') || '') || [])[1] || 'Performance.zip';
    return { buffer: await r2.arrayBuffer(), nome };
  }

  /* ---------- Painel por cima da página ---------- */

  function abrirPainel(modo) {
    document.getElementById('tf-painel')?.remove();
    const fundo = document.createElement('div');
    fundo.id = 'tf-painel';
    fundo.innerHTML = '<div class="tf-painel-caixa"><button type="button" class="tf-painel-fechar" title="Fechar (Esc)">✕</button><iframe class="tf-painel-quadro" allow="clipboard-write"></iframe></div>';
    const quadro = fundo.querySelector('iframe');
    quadro.src = chrome.runtime.getURL('relatorio.html#' + modo);
    quadro.dataset.modo = modo;
    const fechar = () => { fundo.remove(); document.removeEventListener('keydown', esc); };
    const esc = ev => { if (ev.key === 'Escape') fechar(); };
    fundo.querySelector('.tf-painel-fechar').addEventListener('click', fechar);
    document.addEventListener('keydown', esc);
    document.body.appendChild(fundo);
    return quadro;
  }

  function enviarAoPainel(quadro, msg, transferir) {
    const destino = new URL(chrome.runtime.getURL('')).origin;
    const mandar = () => quadro.contentWindow.postMessage(msg, destino, transferir || []);
    if (quadro.dataset.pronto) mandar(); else quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; mandar(); }, { once: true });
  }

  /* ---------- Arquivo guardado (evita gerar de novo antes da próxima atualização) ---------- */
  // O Fraction atualiza a Performance nestes horários; entre um e outro o arquivo não muda.
  const ATUALIZACOES = ['06:24', '08:24', '10:24', '12:24', '14:24', '15:24', '16:24', '19:24', '20:24', '23:24'];
  const CHAVE_CACHE = 'tf_cache_performance';

  /** Momento da última atualização do Fraction (o maior horário ≤ agora; antes das 06h24, a das 23h24 de ontem). */
  function ultimaAtualizacao(agora = new Date()) {
    for (let dia = 0; dia < 2; dia++) {
      for (let i = ATUALIZACOES.length - 1; i >= 0; i--) {
        const [h, m] = ATUALIZACOES[i].split(':').map(Number);
        const t = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() - dia, h, m);
        if (t <= agora) return t;
      }
    }
    return new Date(0);
  }

  /** Identifica a consulta da tela (servidor + números do resumo): outro filtro = outro arquivo. */
  function chaveConsulta() {
    const t = document.getElementById(FORM + ':idTreeTotal_data');
    const resumo = t ? t.textContent.replace(/\s+/g, ' ').trim() : '';
    return location.host + '|' + resumo;
  }

  const paraBase64 = buf => {
    const u8 = new Uint8Array(buf); let s = '';
    for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(s);
  };
  const deBase64 = b64 => { const s = atob(b64), u8 = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i); return u8.buffer; };

  async function lerGuardado() {
    try {
      const c = (await chrome.storage.local.get(CHAVE_CACHE))[CHAVE_CACHE];
      if (c && c.chave === chaveConsulta() && c.quando >= ultimaAtualizacao().getTime() && c.b64) return { buffer: deBase64(c.b64), nome: c.nome, quando: c.quando };
    } catch (e) { console.warn('[TurboFraction] arquivo guardado ilegível', e); }
    return null;
  }

  async function guardar(buffer, nome, quando) {
    try { await chrome.storage.local.set({ [CHAVE_CACHE]: { chave: chaveConsulta(), quando, nome, b64: paraBase64(buffer) } }); }
    catch (e) { console.warn('[TurboFraction] não consegui guardar o arquivo', e); }
  }

  const proxima = () => {
    const ult = ultimaAtualizacao(), hhmm = ult.toTimeString().slice(0, 5);
    const i = ATUALIZACOES.indexOf(hhmm);
    return ATUALIZACOES[(i + 1) % ATUALIZACOES.length].replace(':', 'h');
  };

  async function gerarPainel(btn, forcar) {
    const modo = btn.dataset.modo;
    let quadro = document.querySelector('#tf-painel iframe');
    if (!quadro || quadro.dataset.modo !== modo) {
      quadro = abrirPainel(modo);
      quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; }, { once: true });
    }
    btn.disabled = true;
    const rotulo = btn.textContent;
    btn.textContent = '⏳ Gerando o arquivo…';
    try {
      const guardado = !forcar && await lerGuardado();
      if (guardado) {
        enviarAoPainel(quadro, { tipo: 'tf-arquivo', buffer: guardado.buffer, nome: guardado.nome, quando: guardado.quando, guardado: true, proxima: proxima(), origem: location.origin }, [guardado.buffer]);
        return;
      }
      enviarAoPainel(quadro, { tipo: 'tf-status', texto: 'Gerando o arquivo no Fraction… isso pode levar alguns segundos.', origem: location.origin });
      const { buffer, nome } = await baixarArquivo();
      const quando = Date.now();
      await guardar(buffer, nome, quando);
      enviarAoPainel(quadro, { tipo: 'tf-arquivo', buffer, nome, quando, guardado: false, proxima: proxima(), origem: location.origin }, [buffer]);
    } catch (e) {
      console.warn('[TurboFraction]', e);
      enviarAoPainel(quadro, { tipo: 'tf-status', erro: true, texto: 'Não consegui buscar o arquivo: ' + e.message + '. Clique no total do período para baixar e arraste o arquivo para cá.', origem: location.origin });
    } finally {
      btn.disabled = false;
      btn.textContent = rotulo;
    }
  }

  // "↻ Gerar de novo" dentro do painel
  window.addEventListener('message', ev => {
    const quadro = document.querySelector('#tf-painel iframe');
    if (!quadro || ev.source !== quadro.contentWindow || !ev.data || ev.data.tipo !== 'tf-regerar') return;
    const btn = document.querySelector(`.tf-pend-botao[data-modo="${quadro.dataset.modo}"]`);
    if (btn && !btn.disabled) gerarPainel(btn, true);
  });

  function colocarBotao() {
    if (document.getElementById('tf-pendencias')) return;
    const tabela = document.getElementById(FORM + ':idTreeTotal');
    if (!tabela) return;
    const barra = document.createElement('div');
    barra.className = 'tf-pend-barra';
    const criar = (id, modo, texto, dica) => {
      const btn = document.createElement('button');
      btn.id = id; btn.type = 'button'; btn.className = 'tf-pend-botao';
      btn.dataset.modo = modo; btn.textContent = texto; btn.title = dica;
      btn.addEventListener('click', () => gerarPainel(btn));
      return btn;
    };
    barra.append(
      criar('tf-pendencias', 'painel', '📊 Painel de Pendências', 'Gera o arquivo do total do período e mostra a tabela Status × Descrição'),
      criar('tf-vencimentos', 'vencimentos', '📅 Vencimentos do Dia', 'Remessas ainda não entregues com previsão para hoje, por Circuit ou por Status'),
    );
    tabela.parentElement.insertBefore(barra, tabela);
  }

  try { chrome.storage.local.set({ tf_origem: location.origin }); } catch (e) { /* ok */ }
  colocarBotao();
  new MutationObserver(colocarBotao).observe(document.body, { childList: true, subtree: true });
})();
