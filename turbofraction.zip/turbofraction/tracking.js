/*
 * TurboFraction — tela de consulta da remessa (/FractionWeb/jad/tracking)
 *   • Ícone de mapa ao lado do endereço do destinatário (Google Maps).
 *   • Link do WhatsApp Web nos telefones do remetente e do destinatário.
 *   • CPF/CNPJ do destinatário: Pesquisar com filtro CPF/CNPJ.
 *   • CPF/CNPJ do remetente: Consulta Geral pelo CNPJ Cliente, últimos 30 dias.
 *   • Link ao lado de cada chave: "NF-e ↗" (modelo 55) ou "CT-e ↗" (CT-e, modelo 57).
 *   • Botão "Reimprimir etiqueta": etiqueta 100x75 mm com códigos de barras/QR e a marca REIMP.
 *   • Botão "Protocolo de Acareação": formulário A4 para imprimir/PDF com os dados do destinatário.
 *   • Botão "Gerar ocorrência": cartão com a tela de Ocorrência, remessa preenchida e ENTREGA escolhida.
 * Mesma lógica do Jadlog Scan (trk.js / MainActivity.kt).
 */
(() => {
  'use strict';

  // O modelo (posições 21–22 da chave) diz qual portal consulta: 55 = NF-e, 57 = CT-e.
  const PORTAIS = {
    '57': { rotulo: 'CT-e ↗', nome: 'CT-e', url: 'https://www.cte.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo' },
    '55': { rotulo: 'NF-e ↗', nome: 'NF-e', url: 'https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo&tipoConteudo=7PhJ+gAVw2g=' },
  };
  const URL_OCORRENCIA = location.origin + '/FractionWeb/pages/ocorrencia/ocorrencia.jad';

  const SVG_MAPA = '<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path fill="#C8102E" d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>';

  /* ---------- Quem é o destinatário (os blocos Remetente / Destinatário usam os mesmos rótulos) ---------- */

  const MARCA = /^(Remetente|Destinat[aá]rio|Local de Coleta|Dest\.?:?|Rem\.?:?)s?\s*$/i;
  function marcadores() {
    return [...document.querySelectorAll('label,span,td,th,div,b')]
      .filter(el => { const t = (el.textContent || '').trim(); return t.length <= 20 && MARCA.test(t); });
  }
  function ehDestinatario(el, mk) {
    let melhor = null;
    for (const m of mk) {
      const pos = m.compareDocumentPosition(el);
      if ((pos & Node.DOCUMENT_POSITION_FOLLOWING) && !(pos & Node.DOCUMENT_POSITION_CONTAINED_BY)) melhor = m;
    }
    return !!melhor && /^Dest/i.test((melhor.textContent || '').trim());
  }
  function valorDoRotulo(tbl, re) {
    for (const l of tbl.querySelectorAll('label.labelTracking')) {
      if (re.test((l.textContent || '').trim())) {
        const v = l.closest('td')?.nextElementSibling?.querySelector('label');
        return v ? v.textContent.replace(/\s+/g, ' ').trim() : '';
      }
    }
    return '';
  }

  /** Tabela do bloco Destinatário (a que tem o "End.:" depois do marcador "Destinatário"). */
  function tabelaDestinatario() {
    const mk = marcadores();
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (!/^End\.?\s*:?$/i.test((l.textContent || '').trim())) continue;
      if (ehDestinatario(l, mk)) return l.closest('table');
    }
    return null;
  }

  function dadosDestinatario() {
    const tbl = tabelaDestinatario();
    if (!tbl) return { cliente: '', endereco: '' };
    const end = valorDoRotulo(tbl, /^End\.?\s*:?$/i);
    const bairro = valorDoRotulo(tbl, /^Bairro/i);
    const cidade = valorDoRotulo(tbl, /^Cidade/i).replace(/-BR$/i, '');
    const cep = valorDoRotulo(tbl, /^Cep/i).replace(/^(\d{5})(\d{3})$/, '$1-$2');
    return {
      cliente: valorDoRotulo(tbl, /^(Dest|Nome)\.?\s*:?$/i),
      endereco: [end, bairro, cidade, cep ? 'CEP ' + cep : ''].filter(Boolean).join(' - '),
    };
  }

  /* ---------- Dados para a reimpressão da etiqueta ---------- */

  /** Tabela do bloco cujo marcador casa com `re` (ex.: /^Rem/ ou /^Dest/). */
  function tabelaDoBloco(re) {
    const mk = marcadores();
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (!/^End\.?\s*:?$/i.test((l.textContent || '').trim())) continue;
      let bloco = null;
      for (const m of mk) {
        const pos = m.compareDocumentPosition(l);
        if ((pos & Node.DOCUMENT_POSITION_FOLLOWING) && !(pos & Node.DOCUMENT_POSITION_CONTAINED_BY)) bloco = m;
      }
      if (bloco && re.test(bloco.textContent.trim())) return l.closest('table');
    }
    return null;
  }

  /** Campo de "Informações da Remessa": <label class="labelTracking">Rótulo: </label><label>valor</label>. */
  function info(re) {
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (!re.test((l.textContent || '').trim())) continue;
      const v = l.nextElementSibling;
      if (v && v.tagName === 'LABEL') return v.textContent.replace(/\s+/g, ' ').trim();
    }
    return '';
  }

  /** Linhas da tabela "Histórico" (DOC/AWB, Data, Hora, Unidade, Operação, Ponto Destino). */
  function historico() {
    for (const tb of document.querySelectorAll('table')) {
      const cab = [...tb.querySelectorAll('thead th')].map(th => th.textContent.trim().toLowerCase());
      if (!cab.some(c => c.startsWith('opera')) || !cab.some(c => c.startsWith('ponto'))) continue;
      return [...tb.querySelectorAll('tbody tr')].map(tr => [...tr.querySelectorAll('td')].map(td => td.textContent.replace(/\s+/g, ' ').trim()))
        .filter(c => c.length >= 6);
    }
    return [];
  }

  function dadosEtiqueta(cte) {
    const dest = tabelaDoBloco(/^Dest/i), rem = tabelaDoBloco(/^Rem/i);
    const v = (tbl, re) => tbl ? valorDoRotulo(tbl, re) : '';
    const docs = [...document.querySelectorAll('div[title*="Danfe"]')].map(dv => dv.textContent.replace(/\s+/g, ' ').trim());
    const nf = docs.map(t => (/^NF:\s*(\d+)/.exec(t) || [])[1]).find(Boolean) || '';
    const pedido = docs.filter(t => !/^NF:/i.test(t)).map(t => t.replace(/\s*Copiar.*$/i, '').trim()).find(Boolean) || '';
    const hist = historico();
    const emis = hist.find(c => /^EMISSAO$/i.test(c[4]));
    const ultimo = hist[hist.length - 1];
    return {
      cte,
      destNome: v(dest, /^(Dest|Nome)\.?\s*:?$/i),
      destEnd: v(dest, /^End\.?\s*:?$/i),
      destBairro: v(dest, /^Bairro/i),
      destCidade: v(dest, /^Cidade/i).replace(/\s*\/\s*/, ' ').replace(/-BR$/i, ''),
      destCep: v(dest, /^Cep/i),
      destFone: v(dest, /^Telefone/i).replace(/\s*WhatsApp.*$/i, ''),
      remNome: v(rem, /^Nome\.?\s*:?$/i),
      remDoc: v(rem, /^(CPF|CNPJ)/i),
      nf, pedido,
      modalidade: info(/^Modalidade/i),
      previsao: info(/^Previs/i),
      shipmentId: info(/^Shipment ID/i),
      codSorter: info(/^Cod\.?\s*Sorter/i),
      circuit: info(/^Circuit/i),
      peso: info(/^Peso:?$/i).replace(',', '.'),
      volumes: info(/^Volumes/i),
      emissao: emis ? emis[1] + ' ' + emis[2] : info(/^Emiss/i),
      unidadeEmissao: emis ? emis[3] : '',
      unidade: ultimo ? ultimo[5] : '',
    };
  }

  /* ---------- Google Maps ---------- */

  function iconesMapa() {
    let mk = null;
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (l.dataset.tfMapa || !/^End\.?\s*:?$/i.test((l.textContent || '').trim())) continue;
      const v = l.closest('td')?.nextElementSibling?.querySelector('label');
      if (!v) continue;
      l.dataset.tfMapa = '1';
      mk = mk || marcadores();
      if (!ehDestinatario(l, mk)) continue;
      const tbl = l.closest('table');
      if (!tbl) continue;
      const endereco = [
        v.textContent.replace(/\s+/g, ' ').trim(),
        valorDoRotulo(tbl, /^Bairro/i),
        valorDoRotulo(tbl, /^Cidade/i).replace(/\s*\/\s*/, ' - ').replace(/-BR$/i, ''),
        valorDoRotulo(tbl, /^Cep/i),
      ].filter(Boolean).join(', ');
      if (!endereco) continue;
      const a = document.createElement('a');
      a.className = 'tf-mapa';
      a.href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(endereco);
      a.target = '_blank';
      a.rel = 'noopener';
      a.title = 'Abrir no Google Maps: ' + endereco;
      a.innerHTML = SVG_MAPA;
      v.parentNode.appendChild(a);
    }
  }

  /* ---------- WhatsApp Web nos telefones do remetente e do destinatário ---------- */

  const SVG_WHATS = '<svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path fill="#25D366" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2z"/><path fill="#fff" d="M17.3 14.6c-.3-.1-1.7-.8-1.9-.9-.3-.1-.5-.1-.7.1l-.9 1.1c-.2.2-.3.2-.6.1a7.6 7.6 0 0 1-3.8-3.3c-.3-.5.3-.5.8-1.6.1-.2 0-.4 0-.5l-.9-2.1c-.2-.5-.5-.5-.7-.5h-.6a1.1 1.1 0 0 0-.8.4 3.4 3.4 0 0 0-1 2.5 5.9 5.9 0 0 0 1.2 3.1 13.5 13.5 0 0 0 5.2 4.6c1.9.8 2.7.9 3.6.7a3 3 0 0 0 2-1.4 2.4 2.4 0 0 0 .2-1.4c-.1-.1-.3-.2-.6-.3z"/></svg>';

  /** Separa os números de um campo de telefone e devolve só os que dá para chamar (com DDD), já com o 55. */
  function numerosWhats(texto) {
    return [...new Set(
      texto.replace(/\u260E/g, ' ').split(/[\/,;]|\se\s/)
        .map(t => t.replace(/\D/g, ''))
        .map(n => (n.startsWith('55') && n.length >= 12) ? n : n.replace(/^0+/, ''))
        .map(n => (n.startsWith('55') && n.length >= 12) ? n : (n.length === 10 || n.length === 11 ? '55' + n : ''))
        .filter(n => n.length >= 12 && n.length <= 13)
    )];
  }

  function linksWhats() {
    let mk = null;
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (l.dataset.tfFone || !/^\s*(Telefone|Fone|Celular)/i.test(l.textContent || '')) continue;
      const v = l.nextElementSibling || l.closest('td')?.nextElementSibling?.querySelector('label');
      if (!v) continue;
      l.dataset.tfFone = '1';
      mk = mk || marcadores();
      // Só nos blocos Remetente e Destinatário.
      let bloco = null;
      for (const m of mk) {
        const pos = m.compareDocumentPosition(l);
        if ((pos & Node.DOCUMENT_POSITION_FOLLOWING) && !(pos & Node.DOCUMENT_POSITION_CONTAINED_BY)) bloco = m;
      }
      if (!bloco || !/^(Rem|Dest)/i.test(bloco.textContent.trim())) continue;
      for (const n of numerosWhats(v.textContent || '')) {
        const a = document.createElement('a');
        a.className = 'tf-whats';
        a.href = 'https://web.whatsapp.com/send?phone=' + n;
        a.target = 'tf-whatsapp'; // reaproveita a mesma aba do WhatsApp Web
        a.rel = 'noopener';
        a.title = 'Chamar +' + n + ' no WhatsApp Web';
        a.innerHTML = SVG_WHATS + '<span>WhatsApp</span>';
        v.parentNode.appendChild(a);
      }
    }
  }

  /* ---------- CPF/CNPJ do remetente e do destinatário: pesquisa por CPF/CNPJ ---------- */

  const URL_PESQUISAR = location.origin + '/FractionWeb/jad/pesquisar';
  const URL_CONSULTA_GERAL = location.origin + '/FractionWeb/jad/consulta';

  // A tela de destino lê este pedido e faz a busca sozinha (vale por 1 minuto).
  function guardar(chave, doc) {
    try { localStorage.setItem(chave, JSON.stringify({ v: doc, t: Date.now() })); } catch (e) { /* sem armazenamento */ }
  }

  function blocoDe(el, mk) {
    let bloco = null;
    for (const m of mk) {
      const pos = m.compareDocumentPosition(el);
      if ((pos & Node.DOCUMENT_POSITION_FOLLOWING) && !(pos & Node.DOCUMENT_POSITION_CONTAINED_BY)) bloco = m;
    }
    return bloco ? bloco.textContent.trim() : '';
  }

  function linksCpf() {
    let mk = null;
    for (const l of document.querySelectorAll('label.labelTracking')) {
      if (l.dataset.tfCpf || !/^\s*(CPF|CNPJ|CPF\s*\/\s*CNPJ)\s*:?\s*$/i.test(l.textContent || '')) continue;
      const v = l.nextElementSibling || l.closest('td')?.nextElementSibling?.querySelector('label');
      if (!v) continue;
      const doc = (v.textContent || '').replace(/\D/g, '');
      if (doc.length !== 11 && doc.length !== 14) continue;
      l.dataset.tfCpf = '1';
      mk = mk || marcadores();
      const bloco = blocoDe(l, mk);
      const remetente = /^Rem/i.test(bloco);
      if (!remetente && !/^Dest/i.test(bloco)) continue;
      const tipo = doc.length === 11 ? 'CPF' : 'CNPJ';
      const a = document.createElement('a');
      a.className = 'tf-cpf';
      a.target = '_blank';
      a.rel = 'noopener';
      a.textContent = v.textContent.trim();
      if (remetente) {
        // Remetente: Consulta Geral pelo campo "CNPJ Cliente", últimos 30 dias (tudo o que ele embarcou).
        a.href = URL_CONSULTA_GERAL;
        a.title = 'Consulta Geral: remessas embarcadas por este ' + tipo + ' nos últimos 30 dias';
        a.addEventListener('click', () => guardar('tf_cons_cnpj', doc));
      } else {
        // Destinatário: Pesquisar com o filtro CPF / CNPJ (outras entregas para a mesma pessoa).
        a.href = URL_PESQUISAR;
        a.title = 'Pesquisar outras entregas para este ' + tipo;
        a.addEventListener('click', () => guardar('tf_pesq_cpf', doc));
      }
      v.textContent = '';
      v.appendChild(a);
    }
  }

  /* ---------- NF-e na Receita ---------- */

  function linksReceita() {
    for (const d of document.querySelectorAll('div[title*="Danfe"]')) {
      if (d.dataset.tfNfe) continue;
      const m = /NFe:\s*([0-9A-Za-z]{44})/.exec(d.textContent || '');
      if (!m) continue;
      d.dataset.tfNfe = '1';
      const chave = m[1];
      const portal = PORTAIS[chave.slice(20, 22)] || PORTAIS['55'];
      const a = document.createElement('a');
      a.className = 'tf-receita';
      a.textContent = portal.rotulo;
      a.href = portal.url + '#tf_chave=' + chave;
      a.target = '_blank';
      a.rel = 'noopener';
      a.title = 'Copia a chave e abre a consulta do ' + portal.nome + ' na Receita (o captcha é com você)';
      a.addEventListener('click', ev => {
        ev.stopPropagation();
        try { navigator.clipboard.writeText(chave); } catch (e) { /* sem área de transferência */ }
      }, true);
      d.appendChild(a);
    }
  }

  /* ---------- Gerar ocorrência ---------- */

  function numeroRemessa() {
    const m = /Conhecimento:\s*(\d{10,})/.exec(document.body.innerText || '');
    return m ? m[1] : '';
  }

  /** Cartão por cima da consulta com a tela de Ocorrência do próprio site. */
  function abrirCartaoOcorrencia(cte) {
    fecharCartaoOcorrencia();
    const fundo = document.createElement('div');
    fundo.id = 'tf-oc-fundo';
    fundo.innerHTML =
      '<div class="tf-oc-cartao" role="dialog" aria-label="Gerar ocorrência">' +
        '<div class="tf-oc-topo">' +
          '<span class="tf-oc-titulo"></span>' +
          '<a class="tf-oc-aba" target="_blank" rel="noopener">Abrir em nova aba ↗</a>' +
          '<button type="button" class="tf-oc-fechar" title="Fechar (Esc)">✕</button>' +
        '</div>' +
        '<iframe class="tf-oc-quadro"></iframe>' +
      '</div>';
    fundo.querySelector('.tf-oc-titulo').textContent = '⚠ Ocorrência — remessa ' + cte;
    const url = URL_OCORRENCIA + '#tf_remessa=' + cte;
    fundo.querySelector('.tf-oc-aba').href = url;
    fundo.querySelector('.tf-oc-aba').addEventListener('click', fecharCartaoOcorrencia);
    fundo.querySelector('.tf-oc-quadro').src = url + '&tf_cartao=1';
    fundo.querySelector('.tf-oc-fechar').addEventListener('click', fecharCartaoOcorrencia);
    fundo.addEventListener('mousedown', ev => { if (ev.target === fundo) fecharCartaoOcorrencia(); });
    document.addEventListener('keydown', escFecha);
    document.body.appendChild(fundo);
  }
  function escFecha(ev) { if (ev.key === 'Escape') fecharCartaoOcorrencia(); }
  function fecharCartaoOcorrencia() {
    document.getElementById('tf-oc-fundo')?.remove();
    document.removeEventListener('keydown', escFecha);
  }

  function botaoOcorrencia() {
    if (document.getElementById('tf-ocorrencia')) return;
    const cte = numeroRemessa();
    if (!cte) return;
    const btn = document.createElement('a');
    btn.id = 'tf-ocorrencia';
    btn.className = 'tf-botao';
    btn.href = URL_OCORRENCIA + '#tf_remessa=' + cte;
    btn.innerHTML = '<span aria-hidden="true">⚠</span> Gerar ocorrência';
    btn.title = 'Abre a tela de Ocorrência com a remessa ' + cte + ' e "ENTREGA" já escolhida';
    btn.addEventListener('click', ev => {
      // Ctrl/Shift/botão do meio continuam abrindo em nova aba.
      if (ev.ctrlKey || ev.shiftKey || ev.metaKey || ev.button !== 0) return;
      ev.preventDefault();
      abrirCartaoOcorrencia(cte);
    });

    // Coloca o botão na linha "Ordem Coleta / Conhecimento / Tomador"; se não achar, fica flutuando.
    const rotulo = [...document.querySelectorAll('label,span,td,b')]
      .find(el => el.children.length === 0 && /^\s*Conhecimento:?\s*$/i.test(el.textContent || ''));
    const linha = rotulo && (rotulo.closest('tr') || rotulo.parentElement);
    const acar = document.createElement('a');
    acar.id = 'tf-acareacao';
    acar.className = 'tf-botao tf-botao-claro';
    acar.href = '#';
    acar.innerHTML = '<span aria-hidden="true">🖨</span> Protocolo de Acareação';
    acar.title = 'Imprime (ou salva em PDF) o Protocolo de Acareação com CT-e, cliente e endereço do destinatário';
    acar.addEventListener('click', ev => {
      ev.preventDefault();
      chrome.runtime.sendMessage({ tipo: 'abrirAcareacao', dados: { cte, ...dadosDestinatario() } });
    });

    const etq = document.createElement('a');
    etq.id = 'tf-etiqueta';
    etq.className = 'tf-botao tf-botao-claro';
    etq.href = '#';
    etq.innerHTML = '<span aria-hidden="true">🏷</span> Reimprimir etiqueta';
    etq.title = 'Gera a etiqueta Jadlog desta remessa (marcada como REIMP) para imprimir';
    etq.addEventListener('click', ev => {
      ev.preventDefault();
      chrome.runtime.sendMessage({ tipo: 'abrirEtiqueta', dados: dadosEtiqueta(cte) });
    });

    if (linha && linha.parentElement) {
      const barra = document.createElement('div');
      barra.className = 'tf-barra';
      barra.append(etq, acar, btn);
      (linha.closest('table') || linha).after(barra);
    } else {
      const barra = document.createElement('div');
      barra.className = 'tf-flutuante';
      barra.append(etq, acar, btn);
      document.body.appendChild(barra);
    }
  }

  function aplicar() { iconesMapa(); linksWhats(); linksCpf(); linksReceita(); botaoOcorrencia(); }
  aplicar();
  // Os painéis do PrimeFaces podem ser redesenhados: reaplica de tempos em tempos.
  setInterval(aplicar, 1000);
})();
