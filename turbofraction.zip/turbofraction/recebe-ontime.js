/*
 * TurboFraction — Recebimento de Remessa: "Entrada On Time"
 * (/FractionWeb/pages/recebeRemessa/recebe.jad — roda no mundo da página, world MAIN)
 *
 * Abre um campo de leitura: cada código lido (Enter do leitor) entra numa fila e, um por vez,
 * a extensão faz o que a pessoa faria — coloca o código no campo Remessa, clica em "Adicionar"
 * e depois em "Processar lista". As mensagens do Fraction não aparecem em popups: os erros vão
 * para um painel lateral, onde ficam. "Item já está na lista" é ignorado.
 * Todo código lido fica guardado (buffer invisível no navegador) e pode ser salvo em .txt.
 */
(() => {
  'use strict';
  if (window.top !== window || window.__tfOnTime) return;
  window.__tfOnTime = true;

  const F = 'form_recebe_remessa';
  const ID = { texto: F + ':txtArea', add: F + ':addLote', processar: F + ':botao_processar_lista' };
  const CHAVE_BUFFER = 'tf_ontime_buffer';
  const CHAVE_ERROS = 'tf_ontime_erros';
  const IGNORAR = /j.\s+est.\s+na\s+lista/i;
  const $id = id => document.getElementById(id);
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  const agora = () => new Date().toLocaleTimeString('pt-BR');

  /* ---------- Acompanhar os pedidos do Fraction ---------- */
  const ouvintes = new Set();
  const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, url) { this.__tfUrl = String(url || ''); return XO.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (corpo) {
    if (/recebe/.test(this.__tfUrl) && typeof corpo === 'string') {
      const f = (/(?:^|&)javax\.faces\.source=([^&]*)/.exec(corpo) || [])[1];
      const origem = f ? decodeURIComponent(f.replace(/\+/g, ' ')) : '';
      this.addEventListener('loadend', () => ouvintes.forEach(fn => fn(origem, this.responseText || '', this.status)));
    }
    return XS.apply(this, arguments);
  };
  function esperarResposta(origem, limite = 60000) {
    return new Promise((ok, falha) => {
      const t = setTimeout(() => { ouvintes.delete(fn); falha(new Error('o Fraction não respondeu')); }, limite);
      const fn = (o, txt, st) => { if (o === origem) { clearTimeout(t); ouvintes.delete(fn); ok({ txt, st }); } };
      ouvintes.add(fn);
    });
  }
  function mensagens(xml) {
    const lista = [];
    const reUpd = /<update id="form_notificacao:(mensagemTmp|mensagemFixa)"><!\[CDATA\[([\s\S]*?)\]\]><\/update>/g;
    let u;
    while ((u = reUpd.exec(xml))) {
      const reMsg = /"?summary"?\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"?detail"?\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"?severity"?\s*:\s*["'](\w+)["']/g;
      let m;
      while ((m = reMsg.exec(u[2]))) {
        const dec = s => { try { return JSON.parse('"' + s + '"'); } catch (e) { return s; } };
        const resumo = dec(m[1]).replace(/<[^>]+>/g, ''), detalhe = dec(m[2]).replace(/<[^>]+>/g, '');
        lista.push({ texto: detalhe && detalhe !== resumo ? detalhe : resumo, nivel: m[3].toLowerCase() });
      }
    }
    if (/<partial-response>\s*<error|<error-name>/.test(xml)) lista.push({ texto: 'Erro do servidor do Fraction', nivel: 'error' });
    return lista;
  }

  const clicar = el => el && el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
  function definir(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  /* ---------- Buffer (todo código lido) ---------- */
  const ler = (k, padrao) => { try { return JSON.parse(localStorage.getItem(k)) || padrao; } catch (e) { return padrao; } };
  const gravar = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* cheio/bloqueado */ } };
  let buffer = ler(CHAVE_BUFFER, []);        // [{c, t}]
  let erros = ler(CHAVE_ERROS, []);          // [{c, t, msg}]

  /* ---------- Fila ---------- */
  const fila = [];
  let rodando = false, ok = 0, falhas = 0, lidosSessao = 0;

  async function processarUm(codigo) {
    const ta = $id(ID.texto), add = $id(ID.add);
    if (!ta || !add) throw new Error('campo Remessa não encontrado');
    // 1) Adicionar
    definir(ta, codigo);
    const r1 = esperarResposta(ID.add);
    clicar(add);
    const t1 = (await r1).txt;
    const m1 = mensagens(t1);
    // Quantos itens a lista do Fraction tem depois do Adicionar (rodapé "Já foram adicionados a lista N itens").
    const qtd = t1.match(/adicionados\s+a\s+lista\s+(\d+)\s+ite/i);
    const listaVazia = /N.o\s+existe\s+item\s+na\s+lista/i.test(t1) && !qtd;
    const err1 = m1.filter(m => /error|fatal|warn/.test(m.nivel) || /erro|inv.lido|n.o\s+localizado|n.o\s+permite/i.test(m.texto)).filter(m => !IGNORAR.test(m.texto));
    if (err1.length) return { ok: false, msg: err1.map(m => m.texto).join(' · ') };
    if (listaVazia) return { ok: false, msg: 'O Fraction não colocou o código na lista' + (m1.length ? ' (' + m1.map(m => m.texto).join(' · ') + ')' : '') };
    await esperar(150);
    // 2) Processar lista
    const proc = $id(ID.processar);
    if (!proc) throw new Error('botão Processar lista não encontrado');
    const r2 = esperarResposta(ID.processar);
    clicar(proc);
    const p = await r2;
    if (p.st >= 400) return { ok: false, msg: 'Erro do servidor (' + p.st + ')' };
    const m2 = mensagens(p.txt).filter(m => !IGNORAR.test(m.texto));
    const err2 = m2.filter(m => /error|fatal|warn/.test(m.nivel) || /erro|inv.lido|n.o\s+permite|bloquead|finalizad/i.test(m.texto));
    if (err2.length) return { ok: false, msg: err2.map(m => m.texto).join(' · ') };
    // Depois do Processar a lista deve esvaziar; se os itens continuam lá, não foi processado.
    const ficou = p.txt.match(/adicionados\s+a\s+lista\s+(\d+)\s+ite/i);
    if (ficou && +ficou[1] > 0) return { ok: false, msg: `Não foi processado: ${ficou[1]} item(ns) continuam na lista do Fraction` + (m2.length ? ` (resposta: ${m2.map(m => m.texto).join(' · ')})` : '') };
    const passos = `Adicionar: ${m1.map(m => m.texto).join(' · ') || (qtd ? qtd[1] + ' item(ns) na lista' : 'ok')} → Processar: ${m2.map(m => m.texto).join(' · ') || 'sem mensagem'}`;
    return { ok: true, msg: (m2[0] && m2[0].texto) || 'Recebida', detalhe: passos };
  }

  async function trabalhar() {
    if (rodando) return;
    rodando = true;
    while (fila.length) {
      const codigo = fila.shift();
      ui.atual(codigo);
      let r;
      try { r = await processarUm(codigo); } catch (e) { r = { ok: false, msg: e.message }; }
      if (r.ok) ok++; else { falhas++; erros.unshift({ c: codigo, t: agora(), msg: r.msg }); gravar(CHAVE_ERROS, erros.slice(0, 500)); }
      ui.resultado(codigo, r);
      await esperar(200);
    }
    rodando = false;
    ui.atual(null);
  }

  function receber(texto) {
    virarDia();
    const cods = (texto.match(/[A-Za-z0-9$-]{4,}/g) || []);
    cods.forEach(c => {
      buffer.push({ c, t: new Date().toISOString() });
      lidosSessao++;
      fila.push(c);
    });
    gravar(CHAVE_BUFFER, buffer);
    ui.contar();
    trabalhar();
  }

  /** Link da consulta da remessa (os 14 primeiros dígitos do código lido), em outra aba. */
  function linkRemessa(codigo, classe) {
    // Só quando o código é a própria remessa (14 dígitos, ou 17 com o volume). QR code e código de barras
    // começam pelo Shipment ID, que não abre a consulta da remessa.
    const cte = (/^(\d{14})(\d{3})?$/.exec(codigo) || [])[1];
    const el = document.createElement(cte ? 'a' : 'span');
    el.className = classe;
    el.textContent = codigo;
    if (cte) { el.href = location.origin + '/FractionWeb/jad/tracking?cte=' + cte; el.target = '_blank'; el.rel = 'noopener'; el.title = 'Abrir a consulta da remessa ' + cte; }
    return el;
  }

  /* ---------- Janela ---------- */
  const ui = {};
  function montar() {
    const caixa = document.createElement('div');
    caixa.id = 'tf-ontime';
    caixa.innerHTML = `
      <div class="ot-topo"><b>⏱ Entrada On Time</b><span class="ot-cont"></span>
        <button type="button" class="ot-salvar" title="Salva um arquivo .txt com todos os códigos lidos">💾 Salvar códigos</button>
        <button type="button" class="ot-fechar" title="Fechar (a leitura em andamento termina)">✕</button></div>
      <div class="ot-arquivo" hidden><span class="ot-arq-txt"></span><button type="button" class="ot-arq-sim">▶ Dar entrada em todos</button><button type="button" class="ot-arq-nao">Cancelar</button></div>
      <div class="ot-solte">📄 Solte aqui o arquivo .txt do buffer para dar entrada de novo</div>
      <div class="ot-corpo">
        <div class="ot-esq">
          <label for="ot-campo">Leia ou digite o código e tecle Enter</label>
          <input id="ot-campo" type="text" autocomplete="off" spellcheck="false">
          <div class="ot-agora"></div>
          <ol class="ot-log" reversed></ol>
        </div>
        <div class="ot-dir">
          <div class="ot-dir-topo"><b>Erros</b><span class="ot-nerros"></span>
            <a href="#" class="ot-copiar">copiar</a><a href="#" class="ot-limpar-erros">limpar</a></div>
          <ul class="ot-erros"></ul>
        </div>
      </div>
      <div class="ot-rodape"><span class="ot-buffer"></span><span class="ot-info" tabindex="0" aria-label="Sobre o buffer">⚠</span></div>`;
    document.body.appendChild(caixa);
    const campo = caixa.querySelector('#ot-campo');
    const log = caixa.querySelector('.ot-log'), listaErros = caixa.querySelector('.ot-erros');

    campo.addEventListener('keydown', ev => {
      if (ev.key !== 'Enter') return;
      ev.preventDefault(); ev.stopPropagation();
      const v = campo.value.trim(); campo.value = '';
      if (v) receber(v);
    });
    campo.addEventListener('paste', ev => {
      const t = (ev.clipboardData || window.clipboardData).getData('text');
      if (/\s/.test(t.trim())) { ev.preventDefault(); receber(t); }
    });
    caixa.querySelector('.ot-fechar').addEventListener('click', fechar);
    caixa.querySelector('.ot-salvar').addEventListener('click', salvar);
    caixa.querySelector('.ot-copiar').addEventListener('click', async ev => {
      ev.preventDefault();
      const t = erros.map(e => `${e.c}\t${e.msg}`).join('\n');
      try { await navigator.clipboard.writeText(t); } catch (e) { const ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
      ev.target.textContent = 'copiado'; setTimeout(() => { ev.target.textContent = 'copiar'; }, 1500);
    });
    caixa.querySelector('.ot-limpar-erros').addEventListener('click', ev => { ev.preventDefault(); erros = []; gravar(CHAVE_ERROS, erros); desenharErros(); });
    // Arrastar um .txt do buffer (ou qualquer lista de códigos) para dar entrada de novo.
    const barraArq = caixa.querySelector('.ot-arquivo');
    let codigosArquivo = [];
    const temArquivo = ev => [...(ev.dataTransfer?.types || [])].includes('Files');
    caixa.addEventListener('dragenter', ev => { if (temArquivo(ev)) { ev.preventDefault(); caixa.classList.add('ot-arrastando'); } });
    caixa.addEventListener('dragover', ev => { if (temArquivo(ev)) { ev.preventDefault(); ev.dataTransfer.dropEffect = 'copy'; } });
    caixa.addEventListener('dragleave', ev => { if (!caixa.contains(ev.relatedTarget)) caixa.classList.remove('ot-arrastando'); });
    caixa.addEventListener('drop', async ev => {
      if (!temArquivo(ev)) return;
      ev.preventDefault();
      caixa.classList.remove('ot-arrastando');
      const arq = ev.dataTransfer.files[0];
      if (!arq) return;
      const texto = await arq.text();
      // Cada linha: código [TAB data]. A linha de título ("Entrada On Time — …") é ignorada.
      codigosArquivo = texto.split(/\r?\n/)
        .filter(l => l.trim() && !/Entrada On Time/i.test(l))
        .map(l => l.trim().split(/[\t;,]|\s{2,}/)[0].trim())
        .filter(c => /^[A-Za-z0-9$-]{4,}$/.test(c));
      barraArq.hidden = false;
      barraArq.querySelector('.ot-arq-txt').textContent = codigosArquivo.length
        ? `${arq.name}: ${codigosArquivo.length} código(s) para dar entrada novamente.`
        : `${arq.name}: nenhum código encontrado no arquivo.`;
      barraArq.querySelector('.ot-arq-sim').hidden = !codigosArquivo.length;
    });
    barraArq.querySelector('.ot-arq-sim').addEventListener('click', () => {
      barraArq.hidden = true;
      if (codigosArquivo.length) receber(codigosArquivo.join('\n'));
      codigosArquivo = [];
      focarCampo();
    });
    barraArq.querySelector('.ot-arq-nao').addEventListener('click', () => { barraArq.hidden = true; codigosArquivo = []; focarCampo(); });

    caixa.querySelector('.ot-info').title =
      'Buffer: cópia de segurança de todos os códigos lidos hoje, guardada neste navegador.\n' +
      'Se o Fraction travar ou a página recarregar, nada se perde: use "💾 Salvar códigos" para baixar o .txt.\n' +
      'Na virada do dia o buffer é salvo sozinho num .txt (EntradaOnTime_AAAAMMDD.txt, na pasta Downloads) e recomeça vazio.\n' +
      'Para dar entrada de novo nos códigos de um .txt, arraste o arquivo para esta janela.';
    // Mantém o cursor no campo de leitura.
    caixa.addEventListener('mouseup', ev => { if (!ev.target.closest('a, button, input, .ot-erros, .ot-log')) campo.focus(); });

    function desenharErros() {
      listaErros.innerHTML = '';
      erros.forEach(e => {
        const li = document.createElement('li');
        li.innerHTML = '<span class="ot-e-hora"></span><div class="ot-e-msg"></div>';
        li.prepend(linkRemessa(e.c, 'ot-e-cod'));
        li.querySelector('.ot-e-hora').textContent = e.t;
        li.querySelector('.ot-e-msg').textContent = e.msg;
        listaErros.appendChild(li);
      });
      caixa.querySelector('.ot-nerros').textContent = erros.length ? String(erros.length) : '';
    }
    ui.contar = () => {
      caixa.querySelector('.ot-cont').textContent = `lidos ${lidosSessao} · ✔ ${ok} · ✖ ${falhas}` + (fila.length ? ` · na fila ${fila.length}` : '');
      caixa.querySelector('.ot-buffer').textContent = `Buffer: ${buffer.length} código(s) guardados neste navegador`;
    };
    ui.aviso = t => { const el = caixa.querySelector('.ot-buffer'); el.textContent = t; setTimeout(() => ui.contar(), 8000); };
    ui.atual = c => { caixa.querySelector('.ot-agora').textContent = c ? `Processando ${c}…` : (fila.length ? '' : 'Pronto para ler.'); ui.contar(); };
    ui.resultado = (c, r) => {
      setTimeout(focarCampo, 0);
      const li = document.createElement('li');
      li.className = r.ok ? 'ot-ok' : 'ot-erro';
      li.innerHTML = ' <span class="ot-l-msg"></span>';
      li.prepend(linkRemessa(c, 'ot-l-cod'));
      // Esquerda: só o resultado curto; o erro completo fica no painel da direita.
      li.querySelector('.ot-l-msg').textContent = r.ok ? '✔ ' + (r.msg || 'salvo com sucesso.') : '✖ Erro';
      li.title = r.ok ? (r.detalhe || '') : (r.msg || '');
      log.prepend(li);
      while (log.children.length > 60) log.lastChild.remove();
      if (!r.ok) desenharErros();
      ui.contar();
    };
    desenharErros();
    ui.contar();
    ui.atual(null);
    return caixa;
  }

  const p2 = n => String(n).padStart(2, '0');
  const diaDe = iso => { const d = new Date(iso); return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`; };
  const hojeStr = () => diaDe(new Date().toISOString());

  /** Baixa um .txt com os códigos (lista = itens do buffer; nome conforme o dia ou a hora). */
  function baixarTxt(lista, nome, titulo) {
    const linhas = lista.map(b => `${b.c}\t${new Date(b.t).toLocaleString('pt-BR')}`);
    const blob = new Blob([`${titulo} — ${lista.length} código(s)\r\n` + linhas.join('\r\n') + '\r\n'], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = nome;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  function salvar() {
    const d = new Date();
    baixarTxt(buffer, `EntradaOnTime_${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}.txt`,
      `Entrada On Time — salvo em ${d.toLocaleString('pt-BR')}`);
  }

  /**
   * Virada do dia: os códigos de dias anteriores são salvos automaticamente num .txt por dia
   * (EntradaOnTime_AAAAMMDD.txt) e saem do buffer, que recomeça com os de hoje.
   */
  function virarDia() {
    const hoje = hojeStr();
    const antigos = buffer.filter(b => diaDe(b.t) !== hoje);
    if (!antigos.length) return;
    const porDia = new Map();
    antigos.forEach(b => { const k = diaDe(b.t); if (!porDia.has(k)) porDia.set(k, []); porDia.get(k).push(b); });
    porDia.forEach((lista, dia) => {
      const [y, m, d] = dia.split('-');
      baixarTxt(lista, `EntradaOnTime_${y}${m}${d}.txt`, `Entrada On Time — ${d}/${m}/${y} (salvo automaticamente na virada do dia)`);
    });
    buffer = buffer.filter(b => diaDe(b.t) === hoje);
    gravar(CHAVE_BUFFER, buffer);
    if (ui.contar) ui.contar();
    if (ui.aviso) ui.aviso(`Buffer de ${[...porDia.keys()].map(k => k.split('-').reverse().slice(0, 2).join('/')).join(', ')} salvo em .txt e zerado.`);
  }


  let janela = null;
  /*
   * Foco sempre no campo de leitura enquanto a janela está aberta: o Fraction devolve, a cada
   * Adicionar/Processar, um script que põe o foco no campo Remessa dele (PrimeFaces.focus).
   */
  const aberta = () => janela && !janela.hidden;
  const focarCampo = () => { if (aberta()) { const c = janela.querySelector('#ot-campo'); if (c && document.activeElement !== c) c.focus({ preventScroll: true }); } };
  document.addEventListener('focusin', ev => {
    if (aberta() && !janela.contains(ev.target)) setTimeout(focarCampo, 0);
  }, true);
  (function travarFocoDoFraction() {
    const pf = window.PrimeFaces;
    if (!pf || typeof pf.focus !== 'function' || pf.focus.__tf) { if (!pf) setTimeout(travarFocoDoFraction, 300); return; }
    const original = pf.focus;
    pf.focus = function () { if (aberta()) { focarCampo(); return; } return original.apply(this, arguments); };
    pf.focus.__tf = true;
  })();

  function abrir() {
    if (!janela) janela = montar();
    virarDia();
    janela.hidden = false;
    document.documentElement.classList.add('tf-ontime-aberto');
    janela.querySelector('#ot-campo').focus();
  }
  function fechar() {
    if (janela) janela.hidden = true;
    document.documentElement.classList.remove('tf-ontime-aberto');
  }

  function colocarBotao() {
    if ($id('tf-ontime-botao')) return;
    const proc = $id(ID.processar);
    if (!proc) return;
    const b = document.createElement('button');
    b.id = 'tf-ontime-botao';
    b.type = 'button';
    b.className = 'ui-button ui-widget ui-corner-all ui-button-text-only tf-ontime-vermelho';
    b.innerHTML = '<span class="ui-button-text ui-c">On Time</span>';
    b.title = 'Entrada On Time: lê os códigos um a um e adiciona e processa cada um automaticamente';
    b.addEventListener('click', abrir);
    const td = document.createElement('td');
    td.appendChild(b);
    proc.closest('tr') ? proc.closest('tr').appendChild(td) : proc.after(b);
    // A tabela dos botões tem largura fixa (230px): deixa crescer para os três caberem numa linha só.
    const tab = proc.closest('table'); if (tab) { tab.removeAttribute('width'); tab.style.width = 'auto'; }
    centralizar();
  }

  /** Centraliza a linha de botões em relação ao quadro "Leitura a partir da etiqueta" logo abaixo. */
  function centralizar() {
    const tab = $id(ID.processar)?.closest('table');
    const quadro = $id(ID.texto)?.closest('table.ui-panelgrid') || $id(ID.texto)?.closest('table');
    if (!tab || !quadro) return;
    const rq = quadro.getBoundingClientRect(), rt = tab.getBoundingClientRect();
    if (!rq.width || !rt.width) return;
    const atual = parseFloat(getComputedStyle(tab).marginLeft) || 0;
    const novo = Math.max(0, Math.round(atual + (rq.left + rq.width / 2) - (rt.left + rt.width / 2)));
    if (Math.abs(novo - atual) > 1) tab.style.marginLeft = novo + 'px';
  }

  colocarBotao();
  addEventListener('resize', centralizar);
  new MutationObserver(() => { colocarBotao(); centralizar(); }).observe(document.body, { childList: true, subtree: true });
})();
