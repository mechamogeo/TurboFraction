/*
 * TurboFraction — Ocorrência para várias remessas (/FractionWeb/pages/ocorrencia/ocorrencia.jad)
 * Roda no "mundo" da página (manifest: world MAIN) para acompanhar os pedidos do próprio Fraction.
 *
 * O campo "Remessa" vira uma caixa maior (máx. 100 remessas). O resto da tela é o original:
 * a pessoa escolhe Ocorrência, Detalhe e Processo e clica no "Processar" do Fraction. Para cada
 * remessa a extensão faz o que a pessoa faria: digita a remessa (o site valida), confere as
 * escolhas e clica em Processar. Com mais de uma remessa, o Processar pede um segundo clique
 * para confirmar. O retorno do Fraction de cada remessa aparece abaixo do formulário.
 */
(() => {
  'use strict';
  if (window.top !== window || window.__tfLote) return;
  window.__tfLote = true;

  const F = 'form_ocorrencia';
  const ID = {
    remessa: F + ':id_remessa', area: F + ':id_remessa_area', massivo: F + ':flagEditMassivo',
    ocorr: F + ':selectOcorrencia', detalhe: F + ':selectDetalhe', processo: F + ':selectProcesso',
    painel: F + ':panel_ocorrencia',
  };
  const LIMITE = 100;
  const $id = id => document.getElementById(id);
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  const texto = el => (el?.textContent || '').replace(/\s+/g, ' ').trim();

  /* ---------- Acompanhar os pedidos do Fraction (XHR do PrimeFaces) ---------- */
  const ouvintes = new Set();
  const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, url) { this.__tfUrl = String(url || ''); return XO.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (corpo) {
    if (/ocorrencia/.test(this.__tfUrl) && typeof corpo === 'string') {
      const fonte = (/(?:^|&)javax\.faces\.source=([^&]*)/.exec(corpo) || [])[1];
      const origem = fonte ? decodeURIComponent(fonte.replace(/\+/g, ' ')) : '';
      this.addEventListener('loadend', () => ouvintes.forEach(f => f(origem, this.responseText || '', this.status)));
    }
    return XS.apply(this, arguments);
  };
  /** Espera a resposta do pedido cuja origem (javax.faces.source) é `origem`. */
  function esperarResposta(origem, limite = 60000) {
    return new Promise((ok, falha) => {
      const t = setTimeout(() => { ouvintes.delete(f); falha(new Error('o Fraction não respondeu')); }, limite);
      const f = (o, txt, st) => { if (o === origem) { clearTimeout(t); ouvintes.delete(f); ok({ txt, st }); } };
      ouvintes.add(f);
    });
  }

  /** Mensagens (growl) da resposta: só as da tela de ocorrência, sem o aviso fixo de coletas. */
  function mensagens(xml) {
    const lista = [];
    const reUpd = /<update id="form_notificacao:(mensagemTmp|mensagemFixa)"><!\[CDATA\[([\s\S]*?)\]\]><\/update>/g;
    let u;
    while ((u = reUpd.exec(xml))) {
      const reMsg = /"?summary"?\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"?detail"?\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"?severity"?\s*:\s*["'](\w+)["']/g;
      let m;
      while ((m = reMsg.exec(u[2]))) {
        const dec = s => { try { return JSON.parse('"' + s + '"'); } catch (e) { return s; } };
        const resumo = dec(m[1]), detalhe = dec(m[2]);
        lista.push({ texto: [resumo, detalhe !== resumo ? detalhe : ''].filter(Boolean).join(' — ').replace(/<[^>]+>/g, ''), nivel: m[3].toLowerCase() });
      }
    }
    if (/<error>|<partial-response>\s*<error/.test(xml)) lista.push({ texto: 'Erro do servidor do Fraction', nivel: 'error' });
    return lista;
  }
  const ruim = msgs => msgs.some(m => /error|fatal/.test(m.nivel));

  /* ---------- Formulário do Fraction ---------- */
  const rotuloMenu = base => texto($id(base + '_label')).toUpperCase();
  const processoMarcado = () => document.querySelector(`input[name="${ID.processo}"]:checked`)?.value || '';
  const rotuloProcesso = () => texto(document.querySelector(`label[for="${document.querySelector(`input[name="${ID.processo}"]:checked`)?.id}"]`));
  const clicar = el => el && el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));

  function definir(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  /** Escolhe um item do menu do PrimeFaces como o usuário (abre o menu e clica no item). */
  async function escolherNoMenu(base, rotulo) {
    if (rotuloMenu(base) === rotulo) return true;
    const painel = $id(base + '_panel');
    const item = painel && [...painel.querySelectorAll('li')].find(li => (li.getAttribute('data-label') || texto(li)).trim().toUpperCase() === rotulo);
    if (!item) return false;
    const resp = esperarResposta(base).catch(() => null);
    clicar($id(base + '_label'));
    await esperar(250);
    clicar(item);
    await Promise.race([resp, esperar(8000)]);
    await esperar(300);
    return rotuloMenu(base) === rotulo;
  }

  async function garantirEscolhas(esc) {
    if (rotuloMenu(ID.ocorr) !== esc.ocorr && !(await escolherNoMenu(ID.ocorr, esc.ocorr))) throw new Error('não consegui manter a Ocorrência ' + esc.ocorr);
    if (rotuloMenu(ID.detalhe) !== esc.detalhe && !(await escolherNoMenu(ID.detalhe, esc.detalhe))) throw new Error('não consegui manter o Detalhe ' + esc.detalhe);
    if (processoMarcado() !== esc.processo) {
      const r = document.querySelector(`input[name="${ID.processo}"][value="${esc.processo}"]`);
      clicar(r?.closest('.ui-radiobutton')?.querySelector('.ui-radiobutton-box'));
      await esperar(200);
      if (processoMarcado() !== esc.processo) { if (r) r.checked = true; }
    }
  }

  function botaoProcessar() {
    return [...($id(ID.painel) || document).querySelectorAll('button')].find(b => /processar/i.test(texto(b)));
  }

  /** Confirmação "incluir ocorrência para todas as remessas deste manifesto": nunca aceitar no lote. */
  function dialogoManifestoAberto() {
    // O PrimeFaces marca aria-hidden="false" quando abre a janela de confirmação.
    const d = [...document.querySelectorAll('.ui-confirm-dialog')].find(x => x.getAttribute('aria-hidden') === 'false' && getComputedStyle(x).display !== 'none');
    if (!d) return false;
    const nao = [...d.querySelectorAll('button')].find(b => /n[aã]o/i.test(texto(b)));
    clicar(nao);
    return true;
  }

  async function processarUma(codigo, esc) {
    await garantirEscolhas(esc);
    const massivo = $id(ID.massivo)?.value === 'S';
    const campo = $id(massivo ? ID.area : ID.remessa);
    if (!campo) throw new Error('campo da remessa não encontrado');
    // 1) Remessa (o site valida ao sair do campo)
    const r1 = esperarResposta(campo.id, 30000);
    definir(campo, codigo);
    const v = await r1;
    const m1 = mensagens(v.txt);
    await esperar(250);
    if (dialogoManifestoAberto()) return { ok: false, msg: 'É um manifesto, não uma remessa — ignorado' };
    if (ruim(m1)) return { ok: false, msg: m1.map(m => m.texto).join(' · ') };
    // 2) Processar
    const btn = botaoProcessar();
    if (!btn) throw new Error('botão Processar não encontrado');
    const r2 = esperarResposta(btn.id, 60000);
    clicar(btn);
    const p = await r2;
    const m2 = mensagens(p.txt);
    await esperar(400);
    if (p.st >= 400) return { ok: false, msg: 'Erro do servidor (' + p.st + ')' };
    return { ok: !ruim(m2), msg: m2.map(m => m.texto).join(' · ') || (ruim(m1) ? '' : 'Processada') };
  }

  /* ---------- Campo de remessas (no lugar do campo original) ---------- */
  function lerCodigos(txt) {
    const vistos = new Set(), lista = [];
    (txt.match(/[A-Za-z0-9][A-Za-z0-9-]{4,29}/g) || []).forEach(c => { if (!vistos.has(c)) { vistos.add(c); lista.push(c); } });
    return lista;
  }

  const estado = { texto: '', rodando: false, confirmarAte: 0, deixarPassar: false, parar: false };
  const escolhas = () => ({ ocorr: rotuloMenu(ID.ocorr), detalhe: rotuloMenu(ID.detalhe), processo: processoMarcado(), rotuloProcesso: rotuloProcesso() });
  const escolhaValida = e => e.ocorr && e.detalhe && !/SELECIONE/.test(e.ocorr) && !/SELECIONE/.test(e.detalhe);

  /** Coloca a caixa maior no lugar do campo "Remessa" (o painel é recriado pelo Fraction a cada Processar). */
  function montarCampo() {
    const original = $id(ID.remessa);
    if (!original || $id('tf-lote-campo')) return;
    document.documentElement.classList.add('tf-lote-ativo');
    const caixa = document.createElement('div');
    caixa.id = 'tf-lote-campo';
    caixa.innerHTML = '<textarea id="tf-lote-lista" rows="6" spellcheck="false" class="ui-inputfield ui-inputtextarea ui-widget ui-state-default ui-corner-all"></textarea>' +
      '<div class="tf-lote-legenda"><span>Máx. 100 remessas</span><span class="tf-lote-conta"></span></div>' +
      '<div class="tf-lote-aviso"></div>';
    const area = $id(ID.area);
    (area || original).after(caixa);
    const ta = caixa.querySelector('textarea');
    if (!estado.texto && original.value.trim()) estado.texto = original.value.trim();
    ta.value = estado.texto;
    ta.readOnly = estado.rodando;
    ta.addEventListener('input', () => { estado.texto = ta.value; estado.confirmarAte = 0; aviso(''); contar(); });
    contar();
  }

  function contar() {
    const el = document.querySelector('#tf-lote-campo .tf-lote-conta');
    if (!el) return;
    const n = lerCodigos(estado.texto).length;
    el.textContent = n ? `${Math.min(n, LIMITE)} remessa(s)` + (n > LIMITE ? ` — só as ${LIMITE} primeiras` : '') : '';
    el.classList.toggle('tf-lote-excesso', n > LIMITE);
  }
  function aviso(t, forte) {
    const el = document.querySelector('#tf-lote-campo .tf-lote-aviso');
    if (el) { el.textContent = t; el.classList.toggle('tf-lote-forte', !!forte); }
  }

  /* ---------- Resultado (fora do painel, para não sumir quando o Fraction redesenha) ---------- */
  function areaResultado() {
    let r = $id('tf-lote-res');
    if (!r) {
      r = document.createElement('div');
      r.id = 'tf-lote-res';
      r.innerHTML = '<div class="tf-lote-res-topo"><span class="tf-lote-res-tit"></span><a href="#" class="tf-lote-parar" hidden>Parar</a></div><ol class="tf-lote-itens"></ol>';
      r.querySelector('.tf-lote-parar').addEventListener('click', ev => {
        ev.preventDefault(); estado.parar = true; ev.target.textContent = 'parando após a remessa atual…';
      });
      $id(F).after(r);
    }
    return r;
  }

  // Remessa preenchida no campo original por outra tela (ex.: "Gerar ocorrência" da consulta): mostra na caixa.
  document.addEventListener('change', ev => {
    if (estado.rodando || ev.target?.id !== ID.remessa) return;
    const v = ev.target.value.trim();
    const ta = $id('tf-lote-lista');
    if (v && ta && !lerCodigos(estado.texto).length) { estado.texto = ta.value = v; contar(); }
  }, true);

  // O clique no "Processar" original passa a processar a lista.
  document.addEventListener('click', ev => {
    if (estado.deixarPassar) return;
    const btn = ev.target.closest && ev.target.closest('button');
    if (!btn || !btn.closest('#' + CSS.escape(ID.painel)) || !/processar/i.test(texto(btn))) return;
    ev.preventDefault(); ev.stopImmediatePropagation();
    if (!estado.rodando) iniciarLote();
  }, true);

  async function iniciarLote() {
    // Remessa já preenchida no campo original (ex.: botão "Gerar ocorrência" da consulta).
    const orig = $id(ID.remessa);
    if (!lerCodigos(estado.texto).length && orig && orig.value.trim()) { estado.texto = orig.value.trim(); const t = $id('tf-lote-lista'); if (t) t.value = estado.texto; contar(); }
    const cods = lerCodigos(estado.texto).slice(0, LIMITE);
    const esc = escolhas();
    if (!cods.length) { aviso('Digite a remessa.', true); return; }
    if (!escolhaValida(esc)) { aviso('Escolha a Ocorrência e o Detalhe.', true); return; }
    if (cods.length > 1 && Date.now() > estado.confirmarAte) {
      estado.confirmarAte = Date.now() + 20000;
      aviso(`Será lançada ${esc.ocorr} / ${esc.detalhe} (${esc.rotuloProcesso}) em ${cods.length} remessas. Clique em Processar de novo para confirmar.`, true);
      return;
    }
    estado.confirmarAte = 0; aviso('');
    estado.rodando = true; estado.parar = false;
    const ta = $id('tf-lote-lista'); if (ta) ta.readOnly = true;
    const res = areaResultado();
    const itens = res.querySelector('.tf-lote-itens'), tit = res.querySelector('.tf-lote-res-tit'), parar = res.querySelector('.tf-lote-parar');
    itens.innerHTML = '';
    parar.hidden = cods.length < 2; parar.textContent = 'Parar';
    const linhas = cods.map(c => {
      const li = document.createElement('li'); li.className = 'tf-lote-espera';
      li.innerHTML = '<span class="tf-lote-cod"></span> <span class="tf-lote-msg"></span>';
      li.firstChild.textContent = c; itens.appendChild(li); return li;
    });
    let ok = 0, falhas = 0, feitas = 0;
    const erros = [];
    const placar = () => { tit.textContent = `Processadas ${feitas} de ${cods.length} — ${ok} ok, ${falhas} com erro`; };
    placar();
    for (let i = 0; i < cods.length; i++) {
      if (estado.parar) break;
      const li = linhas[i];
      li.className = 'tf-lote-agora'; li.lastChild.textContent = 'processando…';
      let r;
      estado.deixarPassar = true;
      try { r = await processarUma(cods[i], esc); }
      catch (e) { r = { ok: false, msg: e.message, parar: /não consegui manter|não encontrado/.test(e.message) }; }
      finally { estado.deixarPassar = false; }
      montarCampo();
      feitas++;
      if (r.ok) ok++; else { falhas++; erros.push(cods[i]); }
      li.className = r.ok ? 'tf-lote-ok' : 'tf-lote-erro';
      li.lastChild.textContent = r.msg || (r.ok ? 'Processada' : 'Erro');
      placar();
      if (r.parar) { tit.textContent += ' — parei: ' + r.msg; break; }
    }
    const naoFeitas = cods.slice(feitas);
    linhas.slice(feitas).forEach(li => { li.lastChild.textContent = 'não processada'; });
    estado.rodando = false;
    parar.hidden = true;
    // Ficam no campo só as remessas com erro ou não processadas, para tentar de novo.
    estado.texto = [...erros, ...naoFeitas].join('\n');
    montarCampo();
    const ta2 = $id('tf-lote-lista'); if (ta2) { ta2.value = estado.texto; ta2.readOnly = false; }
    const campo = $id(ID.remessa); if (campo) campo.value = '';
    contar();
    if (estado.texto) aviso('Ficaram no campo só as remessas com erro ou não processadas.');
  }

  let tentativas = 0;
  const iniciar = () => { montarCampo(); if (!$id('tf-lote-campo') && ++tentativas < 20) setTimeout(iniciar, 500); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
  // O Fraction recria o painel (Processar, troca de detalhe…): recoloca a caixa quando ela some.
  new MutationObserver(() => { if (!$id('tf-lote-campo') && $id(ID.remessa)) montarCampo(); })
    .observe(document.body, { childList: true, subtree: true });
})();
