/*
 * TurboFraction — atalhos dentro do quadro "Bem vindo ao PORTAL JAD" da tela inicial.
 * Cada botão aciona o item correspondente do menu do próprio Fraction (mesmo clique do menu),
 * então respeita as permissões do usuário: se o item não existe no menu (ex.: Performance
 * sem login com MFA), o botão fica desabilitado.
 */
(() => {
  'use strict';
  if (window.top !== window) return;

  const ATALHOS = [
    { rotulo: 'Emissão', icone: '🧾', caminho: ['Operacional', 'Emissão'] },
    { rotulo: 'Recebimento de remessa', icone: '📥', caminho: ['Operacional', 'Manifesto', 'Recebimento Remessa'] },
    { rotulo: 'Envio de remessa', icone: '📤', caminho: ['Operacional', 'Manifesto', 'Envio de remessa'] },
    { rotulo: 'Conferir manifesto', icone: '✅', caminho: ['Operacional', 'Manifesto', 'Conf. Manifesto'] },
    { rotulo: 'Lista de entrega', icone: '🚚', caminho: ['Operacional', 'Lista de Entrega'] },
    { rotulo: 'Devolução', icone: '↩️', caminho: ['Operacional', 'Lista de Devolução'] },
    { rotulo: 'Performance', icone: '📊', caminho: ['Gerencial', 'Performance'], semAcesso: 'Disponível só com login pelo MFA' },
    { rotulo: 'Pesquisar', icone: '🔍', caminho: ['Consultas', 'Pesquisar'] },
  ];
  const txt = el => (el?.textContent || '').replace(/\s+/g, ' ').trim();

  /** Caminho do item no menu: ["Operacional", "Manifesto", "Envio de remessa"]. */
  function caminhoDe(a, menu) {
    const p = [txt(a)];
    for (let e = a.parentElement; e && e !== menu; e = e.parentElement) {
      if (e.matches('li.ui-menu-parent')) { const t = txt(e.querySelector(':scope > a')); if (t && t !== p[0]) p.unshift(t); }
    }
    return p;
  }

  function acharItem(menu, alvo) {
    const fim = alvo[alvo.length - 1].toLowerCase();
    return [...menu.querySelectorAll('a')].find(a => {
      if (txt(a).toLowerCase() !== fim || a.closest('li')?.classList.contains('ui-menu-parent') && a.parentElement.querySelector(':scope > ul')) return false;
      const c = caminhoDe(a, menu).map(s => s.toLowerCase());
      return c.length === alvo.length && c.every((s, i) => s === alvo[i].toLowerCase());
    }) || null;
  }

  /** Quadro "Bem vindo ao PORTAL JAD" da tela inicial (onde os botões entram). */
  function quadroBemVindo() {
    const titulo = [...document.querySelectorAll('.ui-panel-title, legend, h1, h2, h3')]
      .find(el => el.children.length === 0 && /^bem vindo ao portal jad\.?$/i.test(txt(el)));
    if (!titulo) return null;
    const painel = titulo.closest('.ui-panel') || titulo.parentElement?.parentElement;
    return painel?.querySelector('.ui-panel-content') || painel;
  }

  function montar() {
    const menu = document.querySelector('.ui-menubar');
    if (!menu || document.getElementById('tf-atalhos')) return;
    const quadro = quadroBemVindo();
    if (!quadro) return;
    const caixa = document.createElement('nav');
    caixa.id = 'tf-atalhos';
    caixa.setAttribute('aria-label', 'Atalhos TurboFraction');
    ATALHOS.forEach(at => {
      const item = acharItem(menu, at.caminho);
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'tf-at-botao';
      b.innerHTML = '<span class="tf-at-ic"></span><span class="tf-at-tx"></span>';
      b.querySelector('.tf-at-ic').textContent = at.icone;
      b.querySelector('.tf-at-tx').textContent = at.rotulo;
      if (item) {
        b.title = at.caminho.join(' › ');
        b.addEventListener('click', () => { b.classList.add('tf-at-indo'); item.click(); });
      } else {
        b.disabled = true;
        b.title = at.semAcesso || 'Este item não aparece no seu menu do Fraction';
      }
      caixa.appendChild(b);
    });
    quadro.prepend(caixa);
    quadro.style.overflow = 'hidden'; // o quadro cresce junto com os botões
  }

  // A tela de boas-vindas é estática: tenta agora e mais duas vezes (sem vigiar a página o tempo todo).
  montar();
  setTimeout(montar, 600);
  setTimeout(montar, 2000);
})();
