/*
 * TurboFraction — Portais da NF-e e do CT-e (consulta resumida)
 * Preenche a chave de acesso vinda dos links "NF-e ↗" e "CT-e ↗". O captcha é do usuário.
 */
(() => {
  'use strict';
  const m = /tf_chave=([0-9A-Za-z]{44})/.exec(location.hash);
  if (!m) return;
  const chave = m[1];
  let n = 0;
  const t = setInterval(() => {
    const campo = document.getElementById('ctl00_ContentPlaceHolder1_txtChaveAcessoResumo');
    if (campo) {
      if (campo.value !== chave) {
        campo.value = chave;
        campo.dispatchEvent(new Event('input', { bubbles: true }));
        campo.dispatchEvent(new Event('change', { bubbles: true }));
      }
      clearInterval(t);
    } else if (++n > 40) {
      clearInterval(t);
    }
  }, 300);
})();
