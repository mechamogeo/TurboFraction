/*
 * TurboFraction — tela de emissão (/FractionWeb/pages/emissao)
 *   • Botão Limpar em vermelho, com ícone de alerta, afastado dos outros botões do rodapé.
 *   • Clique em Limpar pede confirmação antes de apagar a emissão.
 */
(() => {
  'use strict';

  function textoBotao(el) {
    const cru = el.querySelector('.ui-button-text')?.textContent || el.value || el.textContent || '';
    return cru.replace(/⚠/g, '').replace(/\s+/g, ' ').trim();
  }

  function ehLimpar(el) {
    return /^limpar$/i.test(textoBotao(el));
  }

  function botoesDe(el) {
    return [...el.querySelectorAll('button, input[type="submit"], input[type="button"], input[type="reset"], a.ui-button')]
      .filter(b => textoBotao(b));
  }

  /** Menor bloco que junta o Limpar aos outros botões do rodapé. */
  function barraDo(btn) {
    let el = btn.parentElement;
    while (el && el !== document.body) {
      const botoes = botoesDe(el);
      if (botoes.includes(btn) && botoes.length >= 2 && botoes.length <= 8) return el;
      el = el.parentElement;
    }
    return null;
  }

  function estilizar(btn) {
    btn.classList.add('tf-limpar');
    const rotulo = btn.querySelector('.ui-button-text') || btn;
    if (rotulo.querySelector('.tf-limpar-icone')) return;
    const icone = document.createElement('span');
    icone.className = 'tf-limpar-icone';
    icone.setAttribute('aria-hidden', 'true');
    icone.textContent = '⚠';
    rotulo.prepend(icone);
  }

  function separar(btn) {
    const barra = barraDo(btn);
    if (barra) barra.classList.add('tf-emissao-footer');
  }

  function fecharModal() {
    document.getElementById('tf-limpar-fundo')?.remove();
  }

  function abrirModal(btn) {
    if (document.getElementById('tf-limpar-fundo')) return;
    const fundo = document.createElement('div');
    fundo.id = 'tf-limpar-fundo';
    fundo.innerHTML =
      '<div class="tf-limpar-cartao" role="dialog" aria-modal="true" aria-labelledby="tf-limpar-titulo">' +
        '<div class="tf-limpar-topo"><span id="tf-limpar-titulo">⚠ Confirmar limpeza</span>' +
        '<button type="button" class="tf-limpar-fechar" aria-label="Fechar">×</button></div>' +
        '<p>Limpar apaga os dados preenchidos nesta emissão.</p>' +
        '<div class="tf-limpar-acoes">' +
          '<button type="button" class="tf-limpar-cancelar">Cancelar</button>' +
          '<button type="button" class="tf-limpar-confirmar"><span class="tf-limpar-modal-icone" aria-hidden="true">⚠</span> Limpar</button>' +
        '</div>' +
      '</div>';
    const cartao = fundo.querySelector('.tf-limpar-cartao');
    fundo.addEventListener('click', ev => { if (ev.target === fundo) fecharModal(); });
    cartao.addEventListener('click', ev => ev.stopPropagation());
    fundo.querySelector('.tf-limpar-fechar').addEventListener('click', fecharModal);
    fundo.querySelector('.tf-limpar-cancelar').addEventListener('click', fecharModal);
    fundo.querySelector('.tf-limpar-confirmar').addEventListener('click', () => {
      fecharModal();
      if (!btn.isConnected) return;
      btn.dataset.tfSeguir = '1';
      btn.click();
    });
    fundo.addEventListener('keydown', ev => { if (ev.key === 'Escape') fecharModal(); });
    document.body.appendChild(fundo);
    fundo.querySelector('.tf-limpar-cancelar').focus();
  }

  function aoClicar(ev) {
    const btn = ev.currentTarget;
    if (btn.dataset.tfSeguir === '1') {
      delete btn.dataset.tfSeguir;
      return;
    }
    ev.preventDefault();
    ev.stopPropagation();
    ev.stopImmediatePropagation();
    abrirModal(btn);
  }

  function aplicar() {
    for (const btn of document.querySelectorAll('button, input[type="submit"], input[type="button"], input[type="reset"], a.ui-button')) {
      if (btn.closest('#tf-limpar-fundo') || !ehLimpar(btn)) continue;
      estilizar(btn);
      separar(btn);
      if (btn.dataset.tfLimpar) continue;
      btn.dataset.tfLimpar = '1';
      btn.addEventListener('click', aoClicar, true);
    }
  }

  aplicar();
  setInterval(aplicar, 1000);
})();
