/*
 * TurboFraction — Meu Danfe (meudanfe.com.br)
 * Aberto pelos links DANFE/DACTE da consulta da remessa com "#tf_chave=<chave>":
 * preenche a Chave de Acesso, clica em BUSCAR e, quando o documento é encontrado, em "Exibir DANFE"
 * (se o site pedir verificação, ela fica com você).
 */
(() => {
  'use strict';
  const m = /tf_chave=(\d{44})/.exec(location.hash);
  if (!m) return;
  const chave = m[1];
  history.replaceState(null, '', location.pathname + location.search);
  let n = 0;
  const t = setInterval(() => {
    const campo = document.getElementById('searchTxt');
    const botao = document.getElementById('searchBtn');
    if (!campo || !botao) { if (++n > 40) clearInterval(t); return; }
    clearInterval(t);
    campo.focus();
    const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    d.set.call(campo, chave);
    ['input', 'change', 'keyup'].forEach(e => campo.dispatchEvent(new Event(e, { bubbles: true })));
    setTimeout(() => botao.click(), 500);
    // Quando o resultado aparece, clica em "Exibir DANFE/DACTE" (até 90 s: a verificação do site pode pedir um clique).
    const ini = Date.now();
    const espera = setInterval(() => {
      const opcoes = document.getElementById('optionsDiv');
      const exibir = document.getElementById('showDaBtn');
      const visivel = el => el && el.offsetParent !== null && getComputedStyle(el).display !== 'none';
      if (visivel(opcoes) && visivel(exibir)) {
        clearInterval(espera);
        setTimeout(() => exibir.click(), 300);
      } else if (Date.now() - ini > 90000) clearInterval(espera);
    }, 400);
  }, 250);
})();
