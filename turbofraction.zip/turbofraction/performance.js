/*
 * TurboFraction — Performance de Entrega (/FractionWeb/jad/performance_entrega)
 * Na tela de resultado, o botão "📊 Painel de Pendências" gera o mesmo arquivo do clique
 * no total do período, recebe o .zip direto (sem ir para a pasta Downloads) e abre
 * o painel (tabela Status × Descrição) por cima da página.
 */
(() => {
  'use strict';
  const FORM = 'formTreeTotal';

  const CAB_AJAX = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Faces-Request': 'partial/ajax',
    'X-Requested-With': 'XMLHttpRequest',
  };

  function campos(form) {
    const p = new URLSearchParams();
    form.querySelectorAll('input[name], select[name], textarea[name]').forEach(el => {
      if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
      if (el.type === 'submit' || el.type === 'button') return;
      p.append(el.name, el.value);
    });
    return p;
  }

  function atualizarViewState(xml) {
    const m = /<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[([^\]]*)\]\]>/.exec(xml);
    if (m) document.querySelectorAll('input[name="javax.faces.ViewState"]').forEach(i => { i.value = m[1]; });
  }

  /** Repete o clique no total do período e devolve o arquivo (.zip) como ArrayBuffer. */
  async function baixarArquivo() {
    const form = document.getElementById(FORM);
    const corpo = document.getElementById(FORM + ':idTreeTotal_data');
    const link = corpo && corpo.querySelector('tr a.ui-commandlink');
    const botao = link && link.parentElement.querySelector('button[name]');
    if (!form || !link || !botao) throw new Error('Não encontrei o total do período na tela');
    const acao = form.getAttribute('action') || location.href;

    // 1) Prepara o arquivo (o mesmo pedido do clique no número).
    const p1 = new URLSearchParams({
      'javax.faces.partial.ajax': 'true',
      'javax.faces.source': link.id,
      'javax.faces.partial.execute': '@all',
      'javax.faces.partial.render': 'form_notificacao:mensagemTmp',
      [link.id]: link.id,
    });
    campos(form).forEach((v, k) => p1.set(k, v));
    const r1 = await fetch(acao, { method: 'POST', credentials: 'same-origin', headers: CAB_AJAX, body: p1.toString() });
    const x1 = await r1.text();
    atualizarViewState(x1);
    const args = /<extension[^>]*type="args"[^>]*>([\s\S]*?)<\/extension>/.exec(x1);
    if (args && /"ok"\s*:\s*false/.test(args[1])) throw new Error('O Fraction não gerou o arquivo (tente o clique manual no total)');

    // 2) Baixa o arquivo (o mesmo envio do botão oculto do site).
    const p2 = campos(form);
    p2.set(FORM, FORM);
    p2.set(botao.name, botao.value || '');
    const r2 = await fetch(acao, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: p2.toString(),
    });
    const tipo = r2.headers.get('content-type') || '';
    if (/text\/html|xml/i.test(tipo)) throw new Error('O Fraction respondeu com uma página em vez do arquivo');
    const nome = (/filename="?([^";]+)/i.exec(r2.headers.get('content-disposition') || '') || [])[1] || 'Performance.zip';
    return { buffer: await r2.arrayBuffer(), nome };
  }

  /* ---------- Painel por cima da página ---------- */

  function abrirPainel() {
    document.getElementById('tf-painel')?.remove();
    const fundo = document.createElement('div');
    fundo.id = 'tf-painel';
    fundo.innerHTML = '<div class="tf-painel-caixa"><button type="button" class="tf-painel-fechar" title="Fechar (Esc)">✕</button><iframe class="tf-painel-quadro"></iframe></div>';
    const quadro = fundo.querySelector('iframe');
    quadro.src = chrome.runtime.getURL('relatorio.html#painel');
    const fechar = () => { fundo.remove(); document.removeEventListener('keydown', esc); };
    const esc = ev => { if (ev.key === 'Escape') fechar(); };
    fundo.querySelector('.tf-painel-fechar').addEventListener('click', fechar);
    document.addEventListener('keydown', esc);
    document.body.appendChild(fundo);
    return quadro;
  }

  function enviarAoPainel(quadro, msg, transferir) {
    const destino = new URL(chrome.runtime.getURL('')).origin;
    const mandar = () => quadro.contentWindow.postMessage(msg, destino, transferir || []);
    if (quadro.dataset.pronto) mandar(); else quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; mandar(); }, { once: true });
  }

  async function gerarPainel(btn) {
    const quadro = abrirPainel();
    quadro.addEventListener('load', () => { quadro.dataset.pronto = '1'; }, { once: true });
    btn.disabled = true;
    const rotulo = btn.textContent;
    btn.textContent = '⏳ Gerando o arquivo…';
    try {
      enviarAoPainel(quadro, { tipo: 'tf-status', texto: 'Gerando o arquivo no Fraction… isso pode levar alguns segundos.', origem: location.origin });
      const { buffer, nome } = await baixarArquivo();
      enviarAoPainel(quadro, { tipo: 'tf-arquivo', buffer, nome, origem: location.origin }, [buffer]);
    } catch (e) {
      console.warn('[TurboFraction]', e);
      enviarAoPainel(quadro, { tipo: 'tf-status', erro: true, texto: 'Não consegui buscar o arquivo: ' + e.message + '. Clique no total do período para baixar e arraste o arquivo para cá.', origem: location.origin });
    } finally {
      btn.disabled = false;
      btn.textContent = rotulo;
    }
  }

  function colocarBotao() {
    if (document.getElementById('tf-pendencias')) return;
    const tabela = document.getElementById(FORM + ':idTreeTotal');
    if (!tabela) return;
    const btn = document.createElement('button');
    btn.id = 'tf-pendencias';
    btn.type = 'button';
    btn.className = 'tf-pend-botao';
    btn.textContent = '📊 Painel de Pendências';
    btn.title = 'Gera o arquivo do total do período e mostra a tabela Status × Descrição';
    btn.addEventListener('click', () => gerarPainel(btn));
    tabela.parentElement.insertBefore(btn, tabela);
  }

  try { chrome.storage.local.set({ tf_origem: location.origin }); } catch (e) { /* ok */ }
  colocarBotao();
  new MutationObserver(colocarBotao).observe(document.body, { childList: true, subtree: true });
})();
