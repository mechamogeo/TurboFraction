// TurboFraction — Protocolo de Acareação
// Os dados chegam pelo service worker (chrome.storage.session) com a chave que está no endereço (#id).
(async () => {
  const id = location.hash.slice(1);
  let dados = {};
  try {
    if (id) {
      const v = await chrome.storage.session.get(id);
      dados = v[id] || {};
      await chrome.storage.session.remove(id);
    }
  } catch (e) { /* abre o formulário em branco */ }

  const preencher = (elId, texto) => {
    const el = document.getElementById(elId);
    if (el && texto) { el.textContent = texto; el.title = texto; }
  };
  preencher('cte', dados.cte);
  preencher('cliente', dados.cliente);
  preencher('endereco', dados.endereco);
  if (dados.cte) document.title = 'Protocolo de Acareação - ' + dados.cte;

  // Endereço muito longo: diminui um pouco a fonte (até 10pt) e, se ainda não couber, quebra em duas linhas.
  const end = document.getElementById('endereco');
  end.style.whiteSpace = 'nowrap';
  for (let t = 12; end.scrollWidth > end.clientWidth && t > 10; t -= 0.5) end.style.fontSize = t + 'pt';
  end.style.whiteSpace = '';

  document.getElementById('imprimir').addEventListener('click', () => window.print());
  const logo = document.querySelector('.logo');
  const imprimir = () => setTimeout(() => window.print(), 300);
  if (logo.complete) imprimir(); else logo.addEventListener('load', imprimir, { once: true });
})();
