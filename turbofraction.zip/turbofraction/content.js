/*
 * TurboFraction — content script
 * Tela: Fraction Web > Lista de Entrega
 *
 * Fluxo do botão "Mostrar Status":
 *   1. Para cada lista "Em aberto" visível na tabela, pede ao servidor as
 *      remessas da lista (o mesmo pedido que o site faz ao clicar na linha,
 *      mas sem abrir o diálogo).
 *   2. Consulta o status de todas as remessas de uma vez na tela
 *      Consultas > Consulta (campo CTE, em lote).
 *   3. Desenha a barra: verde = entregue, vermelho = ocorrência,
 *      amarelo = em rota (sem baixa nem ocorrência).
 */
(() => {
  'use strict';

  const URL_TELA = location.origin + location.pathname;
  const FORM = 'form_lista_entrega';
  const TABELA = FORM + ':id_lista_entrega';
  const DETALHE = FORM + ':detalhe_lista_entrega';

  // Resultados por número de lista: { total, verde, vermelho, amarelo, cinza, remessas: [{remessa, status, texto}] }
  const resultados = new Map();
  let rodando = false;

  /* ------------------------------------------------------------------ */
  /* Consulta de status em lote (tela Consultas > Consulta)               */
  /* ------------------------------------------------------------------ */

  const URL_CONSULTA = location.origin + '/FractionWeb/jad/consulta';
  const GRADE = 'formConsultaData:grdConsultaData';
  const TAMANHO_LOTE = 100;

  /**
   * Regra de cores (a partir das colunas Status / Descrição da consulta):
   *   Status contém "ENTREGUE"  -> verde
   *   Status = "EM ROTA"        -> amarelo (a Descrição pode trazer ocorrência
   *                                de tentativa anterior; vai só na dica)
   *   qualquer outro status     -> vermelho (ocorrência)
   */
  function classificar(status) {
    const s = (status || '').toUpperCase().trim();
    if (s.includes('ENTREGUE')) return 'entregue';
    if (s === 'EM ROTA') return 'rota';
    return s ? 'ocorrencia' : 'desconhecido';
  }

  function serializarFormulario(form) {
    const campos = new URLSearchParams();
    form.querySelectorAll('input[name], textarea[name], select[name]').forEach(el => {
      if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
      if (el.type === 'submit' || el.type === 'button') return;
      campos.append(el.name, el.value);
    });
    return campos;
  }

  function lerLinhasResultado(raiz, colunas) {
    const linhas = [];
    raiz.querySelectorAll('tr').forEach(tr => {
      const tds = tr.querySelectorAll(':scope > td');
      if (tds.length < 5) return;
      const txt = i => (tds[i] ? tds[i].textContent.replace(/\s+/g, ' ').trim() : '');
      const codigo = txt(colunas.codigo);
      if (!/^\d{6,}$/.test(codigo)) return;
      linhas.push({ codigo, status: txt(colunas.status), evento: txt(colunas.evento), descricao: txt(colunas.descricao), previsao: txt(colunas.previsao) });
    });
    return linhas;
  }

  function descobrirColunas(doc) {
    const padrao = { codigo: 0, status: 7, evento: 8, descricao: 9, previsao: 13 };
    const ths = doc.querySelectorAll('[id="' + GRADE + '_head"] th, #' + CSS.escape(GRADE) + ' thead th');
    if (!ths.length) return padrao;
    const nomes = [...ths].map(th => th.textContent.trim().toLowerCase());
    const achar = (re, def) => { const i = nomes.findIndex(n => re.test(n)); return i >= 0 ? i : def; };
    return {
      codigo: achar(/^c.digo$/, padrao.codigo),
      status: achar(/^status$/, padrao.status),
      evento: achar(/evento/, padrao.evento),
      descricao: achar(/^descri/, padrao.descricao),
      previsao: achar(/^previs/, padrao.previsao),
    };
  }

  // O servidor às vezes devolve endereços com http://; o Chrome bloqueia isso numa página https.
  function urlSegura(u, base) {
    const url = new URL(u, base || location.href);
    if (url.protocol === 'http:' && location.protocol === 'https:') url.protocol = 'https:';
    return url.href;
  }

  const CABECALHO_AJAX = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Faces-Request': 'partial/ajax',
    'X-Requested-With': 'XMLHttpRequest',
  };

  /** Envia um POST ajax do JSF e, se a resposta for um <redirect>, abre a página de destino. */
  async function postarESeguir(acao, corpo) {
    const resp = await fetch(urlSegura(acao), { method: 'POST', credentials: 'same-origin', headers: CABECALHO_AJAX, body: corpo.toString() });
    const texto = await resp.text();
    const red = texto.match(/<redirect\s+url="([^"]+)"/);
    if (red) {
      const destino = urlSegura(red[1].replace(/&amp;/g, '&'), resp.url);
      const r2 = await fetch(destino, { credentials: 'same-origin' });
      return { html: await r2.text(), url: r2.url };
    }
    if (/<partial-response/.test(texto)) {
      const msg = (texto.match(/<error-message>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/error-message>/) || [])[1];
      throw new Error(msg ? 'Erro do servidor: ' + msg : 'O servidor não abriu a página');
    }
    return { html: texto, url: resp.url };
  }

  /** Pergunta ao service worker para onde o servidor tentou redirecionar (ele enxerga o cabeçalho Location). */
  async function redirecionamentoCapturado(desde) {
    for (let i = 0; i < 10; i++) {
      try {
        const r = await chrome.runtime.sendMessage({ tipo: 'ultimoRedirecionamentoConsulta', desde });
        if (r && r.url) return r.url;
      } catch (e) { /* service worker acordando */ }
      await esperar(150);
    }
    return null;
  }

  /**
   * Abre um novo fluxo da tela de Consulta.
   * O servidor responde a /jad/consulta com um redirecionamento para http://...?execution=eNs1,
   * que o Chrome bloqueia numa página https. O service worker captura esse endereço e
   * nós abrimos a mesma chave de fluxo via https.
   */
  async function abrirTelaConsulta() {
    const inicio = Date.now();
    try {
      const r = await fetch(urlSegura(URL_CONSULTA), { credentials: 'same-origin' });
      return { html: await r.text(), url: r.url };
    } catch (e) {
      const destino = await redirecionamentoCapturado(inicio);
      if (!destino) throw new Error('Não consegui abrir a tela de consulta (redirecionamento bloqueado)');
      const r = await fetch(urlSegura(destino), { credentials: 'same-origin' });
      return { html: await r.text(), url: r.url };
    }
  }

  async function consultarLote(remessas) {
    // 1) Abre um novo fluxo da tela de consulta.
    const tela = await abrirTelaConsulta();
    let doc = new DOMParser().parseFromString(tela.html, 'text/html');
    const form = doc.getElementById('frmConsulta');
    if (!form) throw new Error('Não abriu a tela de consulta (sessão expirada?)');

    // 2) Preenche o campo CTE (uma remessa por linha) e aciona o "Processar" como o site faz.
    const botao = 'frmConsulta:id_enviar';
    const corpo = new URLSearchParams({ 'javax.faces.partial.ajax': 'true', 'javax.faces.source': botao, 'javax.faces.partial.execute': '@all', [botao]: botao });
    serializarFormulario(form).forEach((v, k) => corpo.set(k, v));
    corpo.set('frmConsulta:cte', remessas.join('\r\n'));
    const res = await postarESeguir(urlSegura(form.getAttribute('action') || tela.url, tela.url), corpo);
    const resp = { url: res.url };
    doc = new DOMParser().parseFromString(res.html, 'text/html');
    const tbody = doc.getElementById(GRADE + '_data');
    if (!tbody) throw new Error('A consulta não retornou a tabela de resultado');
    const colunas = descobrirColunas(doc);
    let linhas = lerLinhasResultado(tbody, colunas);

    // 3) O resultado vem paginado (25 por página): pede todas as linhas de uma vez.
    const formRes = doc.getElementById('formConsultaData');
    const temMaisPaginas = doc.querySelectorAll('[id="' + GRADE + '_paginator_top"] .ui-paginator-page').length > 1
      || linhas.length >= 25;
    if (formRes && temMaisPaginas) {
      const vs = formRes.querySelector('input[name="javax.faces.ViewState"]')?.value || '';
      const acaoRes = urlSegura(formRes.getAttribute('action') || resp.url, resp.url);
      const corpo = new URLSearchParams({
        'javax.faces.partial.ajax': 'true',
        'javax.faces.source': GRADE,
        'javax.faces.partial.execute': GRADE,
        'javax.faces.partial.render': GRADE,
        [GRADE + '_pagination']: 'true',
        [GRADE + '_first']: '0',
        [GRADE + '_rows']: '5000',
        [GRADE + '_encodeFeature']: 'true',
        formConsultaData: 'formConsultaData',
        'javax.faces.ViewState': vs,
      });
      try {
        const r2 = await fetch(acaoRes, {
          method: 'POST',
          credentials: 'same-origin',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Faces-Request': 'partial/ajax',
            'X-Requested-With': 'XMLHttpRequest',
          },
          body: corpo.toString(),
        });
        const xml = new DOMParser().parseFromString(await r2.text(), 'text/xml');
        const up = [...xml.querySelectorAll('update')].find(u => u.getAttribute('id') === GRADE);
        if (up) {
          const frag = new DOMParser().parseFromString('<table><tbody>' + up.textContent + '</tbody></table>', 'text/html');
          const todas = lerLinhasResultado(frag, colunas);
          if (todas.length > linhas.length) linhas = todas;
        }
      } catch (e) {
        console.warn('[TurboFraction] paginação da consulta falhou', e);
      }
    }
    return linhas;
  }

  /**
   * Recebe a lista de remessas e devolve Map(remessa -> { status, texto }).
   * Remessas com várias NFs aparecem repetidas no resultado: agrupamos pelo código.
   */
  async function consultarStatusEmLote(remessas, aoProgredir) {
    const mapa = new Map();
    const unicas = [...new Set(remessas)];
    for (let i = 0; i < unicas.length; i += TAMANHO_LOTE) {
      const lote = unicas.slice(i, i + TAMANHO_LOTE);
      const linhas = await consultarLote(lote);
      for (const l of linhas) {
        const st = classificar(l.status);
        const atual = mapa.get(l.codigo);
        // Se as linhas repetidas divergirem, vale a mais avançada: entregue > ocorrência > rota.
        const peso = { entregue: 3, ocorrencia: 2, rota: 1, desconhecido: 0 };
        if (!atual || peso[st] > peso[atual.status]) {
          // Cartão: em rota -> previsão; entregue -> data da entrega; ocorrência -> descrição + previsão.
          const partes = [l.status];
          if (st === 'entregue') { if (l.evento) partes.push('em ' + l.evento.split(' ')[0]); }
          else {
            if (st === 'ocorrencia' && l.descricao) partes.push(l.descricao);
            if (l.previsao) partes.push('Previsão: ' + l.previsao);
          }
          const texto = partes.join(' · ');
          mapa.set(l.codigo, { status: st, texto, statusTexto: l.status, descricao: l.descricao, previsao: l.previsao });
        }
      }
      aoProgredir && aoProgredir(Math.min(i + TAMANHO_LOTE, unicas.length), unicas.length);
    }
    return mapa;
  }

  /* ------------------------------------------------------------------ */
  /* Comunicação com o servidor (PrimeFaces / JSF partial request)        */
  /* ------------------------------------------------------------------ */

  function viewState() {
    const el = document.querySelector('#' + CSS.escape(FORM) + ' input[name="javax.faces.ViewState"]')
      || document.querySelector('input[name="javax.faces.ViewState"]');
    return el ? el.value : '';
  }

  function atualizarViewState(novo) {
    if (!novo) return;
    document.querySelectorAll('input[name="javax.faces.ViewState"]').forEach(i => { i.value = novo; });
  }

  async function pedidoParcial(campos) {
    // Igual ao PrimeFaces: envia todos os campos do formulário e depois os parâmetros do pedido.
    const corpo = new URLSearchParams();
    const form = document.getElementById(FORM);
    if (form) {
      form.querySelectorAll('input[name], textarea[name], select[name]').forEach(el => {
        if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
        if (el.type === 'submit' || el.type === 'button' || el.disabled) return;
        corpo.set(el.name, el.value);
      });
    }
    corpo.set('javax.faces.partial.ajax', 'true');
    corpo.set(FORM, FORM);
    corpo.set('javax.faces.ViewState', viewState());
    for (const k in campos) corpo.set(k, campos[k]);
    corpo.delete('javax.faces.partial.ajax');
    // A ordem usada pelo PrimeFaces: parâmetros do pedido primeiro.
    const final = new URLSearchParams({ 'javax.faces.partial.ajax': 'true' });
    corpo.forEach((v, k) => final.append(k, v));
    const resp = await fetch(URL_TELA, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Faces-Request': 'partial/ajax',
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: final.toString(),
    });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const xml = new DOMParser().parseFromString(await resp.text(), 'text/xml');

    const redirect = xml.querySelector('redirect');
    if (redirect) throw new Error('Sessão expirada — faça login novamente');
    const erro = xml.querySelector('error');
    if (erro) throw new Error('Erro do servidor: ' + (erro.querySelector('error-message')?.textContent || ''));

    const updates = {};
    xml.querySelectorAll('update').forEach(u => { updates[u.getAttribute('id')] = u.textContent; });
    for (const id in updates) {
      if (id.includes('javax.faces.ViewState')) atualizarViewState(updates[id].trim());
    }
    return updates;
  }

  function extrairRemessas(htmlLinhas) {
    // O conteúdo pode vir como a tabela inteira ou só as <tr>; envolvemos em <table> para o parser aceitar <tr> soltas.
    const doc = new DOMParser().parseFromString('<table><tbody>' + htmlLinhas + '</tbody></table>', 'text/html');
    const linhas = doc.querySelectorAll('tr[data-ri], tbody[id$="_data"] > tr, tbody > tr');
    const vistos = new Set();
    const lista = [];
    linhas.forEach(tr => {
      if (tr.closest('thead')) return;
      const td = tr.querySelector('td');
      if (!td || td.hasAttribute('colspan')) return; // "No records found."
      const remessa = td.textContent.trim();
      if (remessa && !vistos.has(remessa)) { vistos.add(remessa); lista.push(remessa); }
    });
    return lista;
  }

  // Se o pedido direto falhar uma vez, as próximas listas vão direto pelo clique.
  let usarClique = false;

  async function buscarRemessasDaLista(numeroLista) {
    if (!usarClique) {
      try {
        const r = await buscarRemessasPorPedido(numeroLista);
        if (r.length) return r;
        throw new Error('pedido direto não trouxe remessas');
      } catch (e) {
        console.info('[TurboFraction] pedido direto falhou, usando o clique na linha:', e.message);
        usarClique = true;
      }
    }
    return buscarRemessasPorClique(numeroLista);
  }

  const esperar = ms => new Promise(r => setTimeout(r, ms));

  async function esperarAte(cond, limiteMs = 15000) {
    const ini = Date.now();
    while (Date.now() - ini < limiteMs) {
      if (cond()) return true;
      await esperar(150);
    }
    return false;
  }

  const corpoDetalhe = () => document.getElementById(DETALHE + '_data');

  /**
   * Plano B: faz o que o usuário faria — clica na linha, espera o diálogo
   * carregar, mostra 100 por página, lê as remessas e fecha o diálogo.
   */
  async function buscarRemessasPorClique(numeroLista) {
    const tr = linhasDaTabela().find(t => t.dataset.rk === numeroLista);
    if (!tr) throw new Error('Lista não está visível na tabela');
    const dialogo = document.getElementById(FORM + ':dialog_mostra_detalhe_lista_entrega');
    const aberto = () => dialogo && dialogo.getAttribute('aria-hidden') === 'false';
    const antes = corpoDetalhe()?.innerHTML;
    tr.querySelector('td').dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    // Carregou quando o diálogo abre (ou, se não der para saber, quando o conteúdo muda).
    const ok = await esperarAte(() => aberto() || corpoDetalhe()?.innerHTML !== antes);
    if (!ok) throw new Error('O diálogo da lista não carregou');
    await esperar(400);

    // Mostra todas as remessas numa página só, se houver mais de uma página.
    const paginas = document.querySelectorAll('[id="' + DETALHE + '_paginator_bottom"] .ui-paginator-page').length;
    const rpp = document.querySelector('select[name="' + DETALHE + '_rppDD"]');
    if (paginas > 1 && rpp) {
      const antes2 = corpoDetalhe()?.innerHTML;
      rpp.value = '100';
      rpp.dispatchEvent(new Event('change', { bubbles: true }));
      await esperarAte(() => corpoDetalhe()?.innerHTML !== antes2, 10000);
      await esperar(300);
    }
    const remessas = extrairRemessas(corpoDetalhe()?.innerHTML || '');

    // Fecha o diálogo pelo botão "Fechar" do próprio site e espera a tabela voltar.
    const fechar = dialogo && [...dialogo.querySelectorAll('button')].find(b => /fechar/i.test(b.textContent));
    if (fechar) fechar.click();
    await esperarAte(() => !aberto(), 5000);
    await esperar(500);
    if (!remessas.length) throw new Error('Lista sem remessas no detalhe');
    return remessas;
  }

  async function buscarRemessasPorPedido(numeroLista) {
    // 1) Seleciona a lista no servidor (equivale a clicar na linha).
    let updates = await pedidoParcial({
      'javax.faces.source': TABELA,
      'javax.faces.partial.execute': TABELA,
      'javax.faces.partial.render': DETALHE,
      'javax.faces.behavior.event': 'rowSelect',
      'javax.faces.partial.event': 'rowSelect',
      [TABELA + '_instantSelectedRowKey']: numeroLista,
      [TABELA + '_selection']: numeroLista,
    });
    const primeiraPagina = updates[DETALHE] ? extrairRemessas(updates[DETALHE]) : [];

    // 2) Pede todas as linhas do detalhe de uma vez (o diálogo pagina de 10 em 10).
    try {
      updates = await pedidoParcial({
        'javax.faces.source': DETALHE,
        'javax.faces.partial.execute': DETALHE,
        'javax.faces.partial.render': DETALHE,
        [DETALHE + '_pagination']: 'true',
        [DETALHE + '_first']: '0',
        [DETALHE + '_rows']: '1000',
        [DETALHE + '_encodeFeature']: 'true',
      });
      const todas = updates[DETALHE] ? extrairRemessas(updates[DETALHE]) : [];
      if (todas.length >= primeiraPagina.length) return todas;
    } catch (e) {
      console.warn('[TurboFraction] paginação do detalhe falhou, usando a 1ª página', e);
    }
    return primeiraPagina;
  }

  /* ------------------------------------------------------------------ */
  /* Tela: botão, coluna e barras                                         */
  /* ------------------------------------------------------------------ */

  function linhasDaTabela() {
    const tbody = document.getElementById(TABELA + '_data');
    return tbody ? [...tbody.querySelectorAll(':scope > tr[data-rk]')] : [];
  }

  function emAberto(tr) {
    const tds = tr.querySelectorAll(':scope > td[role="gridcell"]');
    return tds[5] && /em aberto/i.test(tds[5].textContent);
  }

  function garantirColuna() {
    const head = document.getElementById(TABELA + '_head');
    const linhaHead = head && head.querySelector('tr');
    if (linhaHead && !linhaHead.querySelector('.jst-col')) {
      const th = document.createElement('th');
      th.className = 'ui-state-default jst-col';
      th.innerHTML = '<span class="ui-column-title">Status</span>';
      linhaHead.appendChild(th);
    }
    linhasDaTabela().forEach(tr => {
      let td = tr.querySelector(':scope > td.jst-cell');
      if (!td) {
        td = document.createElement('td');
        td.className = 'jst-cell';
        // Evita que o clique na barra abra o diálogo da lista.
        td.addEventListener('click', ev => ev.stopPropagation());
        td.addEventListener('mouseenter', () => abrirCartao(td));
        td.addEventListener('mouseleave', agendarFechar);
        tr.appendChild(td);
      }
      const r = resultados.get(tr.dataset.rk);
      if (r && td.dataset.versao !== String(r.versao)) desenharBarra(td, r);
    });
  }

  function desenharBarra(td, r) {
    td.dataset.versao = String(r.versao);
    if (r.aviso) {
      td.innerHTML = '';
      const div = document.createElement('div');
      div.className = 'jst-aviso';
      div.textContent = r.aviso;
      td.appendChild(div);
      return;
    }
    if (r.erro) {
      td.innerHTML = '';
      const div = document.createElement('div');
      div.className = 'jst-erro';
      div.textContent = r.erro;
      td.appendChild(div);
      return;
    }
    const total = r.total || 1;
    const pct = n => (100 * n / total) + '%';
    td.innerHTML =
      '<div class="jst-bar">' +
        `<div class="jst-seg jst-verde" style="width:${pct(r.verde)}"></div>` +
        `<div class="jst-seg jst-vermelho" style="width:${pct(r.vermelho)}"></div>` +
        `<div class="jst-seg jst-amarelo" style="width:${pct(r.amarelo)}"></div>` +
        `<div class="jst-seg jst-cinza" style="width:${r.carregando ? '0%' : pct(r.cinza)}"></div>` +
      '</div>' +
      '<div class="jst-legenda"></div>';
    td.querySelector('.jst-legenda').textContent = r.carregando
      ? r.etapa
      : `${r.verde} entregue · ${r.vermelho} ocorr. · ${r.amarelo} em rota` + (r.cinza ? ` · ${r.cinza} ?` : '');
  }

  /* ---------- Cartão com as remessas (aparece ao passar o mouse na barra) ---------- */

  const URL_TRACKING = location.origin + '/FractionWeb/jad/tracking?cte=';
  const ORDEM = { ocorrencia: 0, rota: 1, desconhecido: 2, entregue: 3 };
  const COR = { ocorrencia: 'jst-vermelho', rota: 'jst-amarelo', entregue: 'jst-verde', desconhecido: 'jst-cinza' };
  let cartao = null, fecharTimer = null;
  const hojeDMA = () => { const d = new Date(); return [d.getDate(), d.getMonth() + 1].map(n => String(n).padStart(2, '0')).join('/') + '/' + d.getFullYear(); };

  function obterCartao() {
    if (cartao) return cartao;
    cartao = document.createElement('div');
    cartao.id = 'jst-cartao';
    cartao.addEventListener('mouseenter', () => clearTimeout(fecharTimer));
    cartao.addEventListener('mouseleave', agendarFechar);
    document.body.appendChild(cartao);
    return cartao;
  }

  function agendarFechar() {
    clearTimeout(fecharTimer);
    fecharTimer = setTimeout(() => { if (cartao) cartao.style.display = 'none'; }, 300);
  }

  function abrirCartao(td) {
    const r = resultados.get(td.closest('tr')?.dataset.rk);
    if (!r || !r.remessas.length || r.carregando) return;
    clearTimeout(fecharTimer);
    const c = obterCartao();
    c.innerHTML = '';
    const titulo = document.createElement('div');
    titulo.className = 'jst-cartao-titulo';
    const linha = td.closest('tr');
    const rota = (linha.querySelectorAll(':scope > td[role="gridcell"]')[7]?.textContent || '').replace(/\s+/g, ' ').trim();
    titulo.textContent = `Lista ${linha.dataset.rk}` + (rota ? ` — Rota ${rota}` : '') + ` — ${r.remessas.length} remessa(s)`;
    c.appendChild(titulo);
    [...r.remessas]
      .sort((a, b) => (ORDEM[a.status] ?? 9) - (ORDEM[b.status] ?? 9))
      .forEach(x => {
        const linha = document.createElement('div');
        linha.className = 'jst-cartao-linha';
        const bola = document.createElement('span');
        bola.className = 'jst-bola ' + (COR[x.status] || 'jst-cinza');
        const link = document.createElement('a');
        link.href = URL_TRACKING + encodeURIComponent(x.remessa);
        link.target = '_blank';
        link.rel = 'noopener';
        link.textContent = x.remessa;
        const info = document.createElement('span');
        info.className = 'jst-cartao-info';
        // Previsão de entrega igual a hoje fica em negrito.
        (x.texto || x.status || '').split(' · ').forEach((parte, k) => {
          if (k) info.append(' · ');
          const m = /^Previsão:\s*(\d{2}\/\d{2}\/\d{4})/.exec(parte);
          if (m && m[1] === hojeDMA()) {
            const b = document.createElement('b');
            b.className = 'jst-hoje';
            b.textContent = parte;
            info.append(b);
          } else info.append(parte);
        });
        linha.append(bola, link, info);
        c.appendChild(linha);
      });
    // Posiciona ao lado da barra, sem sair da tela.
    c.style.display = 'block';
    const ret = td.getBoundingClientRect();
    const larg = c.offsetWidth, alt = c.offsetHeight;
    let left = ret.right + 6;
    if (left + larg > window.innerWidth - 8) left = Math.max(8, ret.left - larg - 6);
    let top = Math.min(ret.top, window.innerHeight - alt - 8);
    c.style.left = left + 'px';
    c.style.top = Math.max(8, top) + 'px';
  }

  function garantirBotao() {
    const baixar = document.getElementById(FORM + ':botao_chama_confirm');
    if (!baixar || document.getElementById('jst-mostrar-status')) return;
    const td = document.createElement('td');
    const btn = document.createElement('button');
    btn.id = 'jst-mostrar-status';
    btn.type = 'button';
    btn.className = 'ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only jst-btn';
    btn.innerHTML = '<span class="ui-button-text ui-c">Mostrar Status</span>';
    btn.addEventListener('click', mostrarStatus);
    td.appendChild(btn);
    const venc = document.createElement('button');
    venc.id = 'jst-vencimento';
    venc.type = 'button';
    venc.className = 'ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only jst-btn';
    venc.innerHTML = '<span class="ui-button-text ui-c">Vencimento do Dia</span>';
    venc.title = 'Remessas com previsão de entrega para hoje (ainda não entregues), agrupadas por rota — texto para o WhatsApp';
    venc.addEventListener('click', vencimentoDoDia);
    td.appendChild(venc);
    baixar.closest('td').after(td);
    atualizarBotao();
  }

  function atualizarBotao() {
    const btn = document.getElementById('jst-mostrar-status');
    if (!btn) return;
    btn.disabled = rodando;
    btn.classList.toggle('ui-state-disabled', rodando);
    btn.querySelector('span').textContent = rodando ? 'Consultando…' : 'Mostrar Status';
    const venc = document.getElementById('jst-vencimento');
    if (venc) { venc.disabled = rodando; venc.classList.toggle('ui-state-disabled', rodando); }
  }

  /* ---------- Vencimento do Dia: texto para o WhatsApp ---------- */

  async function vencimentoDoDia() {
    // Usa o resultado do "Mostrar Status"; se ainda não rodou nesta página, roda agora.
    const visiveis = linhasDaTabela().map(tr => tr.dataset.rk);
    const faltam = visiveis.filter(n => { const r = resultados.get(n); return !r || (r.carregando && !r.aviso); });
    if (faltam.length) await mostrarStatus();

    const hoje = hojeDMA();
    const porRota = new Map();
    let total = 0;
    for (const n of visiveis) {
      const r = resultados.get(n);
      if (!r || !r.remessas) continue;
      for (const x of r.remessas) {
        if (x.previsao !== hoje || x.status === 'entregue') continue;
        const rota = r.rota || 'SEM ROTA';
        if (!porRota.has(rota)) porRota.set(rota, []);
        porRota.get(rota).push({ ...x, lista: n });
        total++;
      }
    }

    const linhas = [`*VENCIMENTO DO DIA — ${hoje}*`, '_Remessas com previsão de entrega para hoje ainda não entregues_', ''];
    if (!total) {
      linhas.push('Nenhuma remessa pendente com vencimento hoje nas listas consultadas. ✅');
    } else {
      [...porRota.keys()].sort((a, b) => a.localeCompare(b, 'pt-BR')).forEach(rota => {
        const itens = porRota.get(rota);
        linhas.push(`🚚 *ROTA ${rota.toUpperCase()}* (${itens.length})`);
        itens
          .sort((a, b) => a.lista.localeCompare(b.lista) || (a.status === 'ocorrencia' ? 0 : 1) - (b.status === 'ocorrencia' ? 0 : 1))
          .forEach(x => {
            const st = x.status === 'ocorrencia'
              ? `⚠️ ${x.statusTexto || 'OCORRÊNCIA'}${x.descricao ? ' (' + x.descricao + ')' : ''}`
              : (x.statusTexto || 'EM ROTA');
            linhas.push(`• Lista ${x.lista} | ${x.remessa} — ${st}`);
          });
        linhas.push('');
      });
      linhas.push(`*Total: ${total} remessa(s) em ${porRota.size} rota(s)*`);
    }
    mostrarTexto(linhas.join('\n').trim());
  }

  function mostrarTexto(texto) {
    document.getElementById('jst-texto-fundo')?.remove();
    const fundo = document.createElement('div');
    fundo.id = 'jst-texto-fundo';
    fundo.innerHTML =
      '<div class="jst-texto-cartao" role="dialog" aria-label="Vencimento do Dia">' +
        '<div class="jst-texto-topo"><span>Vencimento do Dia — texto para o WhatsApp</span><button type="button" class="jst-x" title="Fechar (Esc)">✕</button></div>' +
        '<textarea readonly></textarea>' +
        '<div class="jst-texto-acoes"><span class="jst-copiado"></span><button type="button" class="jst-copiar">📋 Copiar texto</button></div>' +
      '</div>';
    const ta = fundo.querySelector('textarea');
    ta.value = texto;
    const fechar = () => { fundo.remove(); document.removeEventListener('keydown', esc); };
    const esc = ev => { if (ev.key === 'Escape') fechar(); };
    fundo.querySelector('.jst-x').addEventListener('click', fechar);
    fundo.addEventListener('mousedown', ev => { if (ev.target === fundo) fechar(); });
    document.addEventListener('keydown', esc);
    fundo.querySelector('.jst-copiar').addEventListener('click', async () => {
      let ok = false;
      try { await navigator.clipboard.writeText(texto); ok = true; }
      catch (e) { ta.select(); ok = document.execCommand('copy'); }
      fundo.querySelector('.jst-copiado').textContent = ok ? 'Copiado! Agora é só colar no WhatsApp.' : 'Selecione o texto e use Ctrl+C.';
    });
    document.body.appendChild(fundo);
    ta.focus(); ta.select();
  }

  /* ------------------------------------------------------------------ */
  /* Execução                                                            */
  /* ------------------------------------------------------------------ */

  const CHAVE_COR = { entregue: 'verde', ocorrencia: 'vermelho', rota: 'amarelo' };

  function novoResultado(qtd) {
    return { total: qtd || 0, verde: 0, vermelho: 0, amarelo: 0, cinza: 0, remessas: [], carregando: true, etapa: 'lendo lista…', versao: 0 };
  }

  function publicar(numero, r) { r.versao++; resultados.set(numero, r); garantirColuna(); }

  async function mostrarStatus() {
    if (rodando) return;
    rodando = true;
    atualizarBotao();
    try {
      const alvo = linhasDaTabela()
        .map(tr => {
          const tds = tr.querySelectorAll('td');
          const peso = parseFloat((tds[2]?.textContent || '').trim().replace(/\./g, '').replace(',', '.'));
          return { numero: tr.dataset.rk, qtd: parseInt(tds[1]?.textContent, 10) || 0, devolucao: peso === 0, rota: (tds[7]?.textContent || '').replace(/\s+/g, ' ').trim() };
        });

      document.body.classList.add('jst-rodando');
      // Para cada lista: lê as remessas e já consulta o status, para as barras irem aparecendo.
      // (uma lista por vez: o servidor guarda "a lista selecionada").
      for (const { numero, qtd, devolucao, rota } of alvo) {
        const r = novoResultado(qtd);
        r.rota = rota;
        // Listas com peso 0,00 são de devolução: não consultamos.
        if (devolucao) {
          r.aviso = 'LISTA DE DEVOLUÇÃO';
          r.carregando = false;
          publicar(numero, r);
          continue;
        }
        publicar(numero, r);
        try {
          const remessas = await buscarRemessasDaLista(numero);
          if (!remessas.length) throw new Error('Nenhuma remessa encontrada');
          r.total = remessas.length;
          r.etapa = 'consultando status…';
          publicar(numero, r);
          let mapa;
          try { mapa = await consultarStatusEmLote(remessas); }
          catch (e) { throw new Error('Consulta: ' + e.message); }
          for (const remessa of remessas) {
            const st = mapa.get(remessa) || { status: 'desconhecido', texto: 'não encontrada na consulta' };
            r.remessas.push({ remessa, ...st });
            r[CHAVE_COR[st.status] || 'cinza']++;
          }
        } catch (e) {
          r.erro = e.message;
          console.warn('[TurboFraction] lista ' + numero + ':', e);
        }
        r.carregando = false;
        publicar(numero, r);
      }
    } finally {
      document.body.classList.remove('jst-rodando');
      rodando = false;
      atualizarBotao();
    }
  }

  /* ------------------------------------------------------------------ */
  /* O PrimeFaces redesenha a tabela ao paginar/filtrar: reaplicamos.     */
  /* ------------------------------------------------------------------ */

  let agendado = false;
  const observador = new MutationObserver(() => {
    if (agendado) return;
    agendado = true;
    requestAnimationFrame(() => {
      agendado = false;
      garantirBotao();
      garantirColuna();
    });
  });

  garantirBotao();
  garantirColuna();
  observador.observe(document.body, { childList: true, subtree: true });
})();
