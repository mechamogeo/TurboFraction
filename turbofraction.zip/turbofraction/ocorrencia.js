/*
 * TurboFraction — tela de Ocorrência (/FractionWeb/pages/ocorrencia/ocorrencia.jad)
 * Quando aberta pelo botão "Gerar ocorrência" (em aba nova ou no cartão da consulta):
 *   1. preenche a remessa;
 *   2. escolhe "ENTREGA" na lista OCORRÊNCIA (o site então carrega a lista de detalhes).
 * O detalhe e o "Processar" ficam com o usuário.
 */
(() => {
  'use strict';
  const m = /tf_remessa=(\d{6,})/.exec(location.hash);
  if (!m) return;
  const remessa = m[1];
  const noCartao = /tf_cartao=1/.test(location.hash);
  // Limpa o hash para não repreencher se a página for recarregada.
  history.replaceState(null, '', location.pathname + location.search);
  if (noCartao) document.documentElement.classList.add('tf-no-cartao');

  const esperar = ms => new Promise(r => setTimeout(r, ms));
  async function esperarElemento(id, limite = 10000) {
    const ini = Date.now();
    while (Date.now() - ini < limite) {
      const el = document.getElementById(id);
      if (el) return el;
      await esperar(200);
    }
    return null;
  }

  function definir(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  const clicar = el => el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));

  /** Escolhe uma opção de um menu do PrimeFaces como o usuário faria: abre o menu e clica no item. */
  async function escolherNoMenu(base, rotulo) {
    const sel = document.getElementById(base + '_input');
    const label = document.getElementById(base + '_label');
    const painel = document.getElementById(base + '_panel');
    if (!sel || !label || !painel) return false;
    const item = () => [...painel.querySelectorAll('li')].find(li => (li.getAttribute('data-label') || '').trim().toUpperCase() === rotulo);
    if (!item()) return false;
    clicar(label);           // abre o menu
    await esperar(400);
    clicar(item());          // escolhe o item (dispara o carregamento dos detalhes)
    await esperar(300);
    return (label.textContent || '').trim().toUpperCase() === rotulo;
  }

  (async () => {
    const campo = await esperarElemento('form_ocorrencia:id_remessa');
    if (!campo) return;
    campo.focus();
    definir(campo, remessa);
    await esperar(800); // validação da remessa pelo site

    const ok = await escolherNoMenu('form_ocorrencia:selectOcorrencia', 'ENTREGA');
    if (!ok) console.info('[TurboFraction] não consegui escolher ENTREGA automaticamente');

    // Deixa a lista de detalhes à vista para o usuário escolher.
    await esperar(1200);
    const det = document.getElementById('form_ocorrencia:selectDetalhe') || document.getElementById('form_ocorrencia');
    if (det) det.scrollIntoView({ block: 'center' });
  })();
})();
