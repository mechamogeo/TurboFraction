// Janela do ícone: verifica na hora se há versão nova no GitHub.
(async () => {
  const $ = id => document.getElementById(id);
  $('atual').textContent = 'versão ' + chrome.runtime.getManifest().version;
  const mostrar = id => ['verificando', 'ok', 'nova', 'erro'].forEach(x => { $(x).hidden = x !== id; });
  try {
    const r = await chrome.runtime.sendMessage({ tipo: 'verificarAgora' });
    if (!r || r.erro) return mostrar('erro');
    if (!r.nova) return mostrar('ok');
    $('versaoNova').textContent = r.nova.versao;
    $('baixar').href = r.nova.download;
    (r.nova.notas || []).forEach(n => { const li = document.createElement('li'); li.textContent = n; $('notas').appendChild(li); });
    mostrar('nova');
  } catch (e) {
    mostrar('erro');
  }
})();
