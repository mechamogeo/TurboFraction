// TurboFraction — Relatório de Pendências (CUSTÓDIA por ocorrência + demais status + transferências × dias parados).
(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const VAZIO = '(vazio)';
  const ENTREGUES = /^ENTREGUE( NO PICKUP)?$/;
  const LIMITE_CARTAO = 300;     // linhas mostradas no cartão
  const LIMITE_PESQUISA = 500;   // remessas enviadas para a Consulta de uma vez

  let dados = [];                // [{codigo, status, desc, ponto, uf, cidade, bairro, rota, circuit, previsao, dias, tratativa}]
  let origem = 'https://www.jadlog.com.br';
  let celulaAtiva = null, fecharTimer = null, listaCartao = [];

  /* ---------- Carregar o arquivo ---------- */

  function estado(t) { $('estado').textContent = t || ''; }

  /** Tela de espera com o cubo girando (texto = null esconde). */
  function carregando(texto) {
    $('carregando').hidden = texto == null;
    $('carregando-texto').textContent = texto || '';
    if (texto != null) $('area').innerHTML = '';
  }

  // Status que entram na tabela (além da CUSTÓDIA, que é aberta por ocorrência).
  const DEMAIS = ['ENTRADA', 'EM ROTA', 'EM DEVOLUCAO', 'DISPONIVEL RETIRADA PICKUP', 'TRAVADO', 'EM ROTA PICKUP', 'EMISSAO', 'UNITIZADO'];
  const TRANSFER = ['TRANSFERENCIA', 'TRANSFERIDO PARA UNIDADE'];

  /** Data "dd/mm/aaaa hh:mm:ss" ou número de série do Excel -> Date (meia-noite). */
  function dataDe(txt) {
    if (!txt) return null;
    let m = /^(\d{2})\/(\d{2})\/(\d{4})/.exec(txt);
    if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
    m = /^(\d{4})-(\d{2})-(\d{2})/.exec(txt);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
    const n = parseFloat(txt.replace(',', '.'));
    if (!isNaN(n) && n > 20000 && n < 80000) { const d = new Date(Date.UTC(1899, 11, 30) + Math.floor(n) * 864e5); return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()); }
    return null;
  }
  const HOJE = (() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); })();
  /** Aging = dias desde o último evento (igual à coluna HOJE() − Dt da planilha). */
  const aging = txt => { const d = dataDe(txt); return d ? Math.round((HOJE - d) / 864e5) : null; };

  async function carregar(arquivo) {
    try {
      carregando('Lendo o arquivo…');
      estado('Lendo ' + arquivo.name + '…');
      const t0 = Date.now();
      const { cabecalho, linhas } = await TFXlsx.lerArquivo(arquivo, t => { estado(t); carregando(t); });
      const col = (...nomes) => { for (const n of nomes) { const i = cabecalho.findIndex(h => h.toLowerCase() === n.toLowerCase()); if (i >= 0) return i; } return -1; };
      const c = {
        codigo: col('Codigo'), status: col('Status'), desc: col('Descricao'), ponto: col('Hist. ultimo ponto'), uf: col('Hist. ultima uf'),
        cidade: col('Cidade'), bairro: col('Bairro'), rota: col('Rota'), circuit: col('Circuit'),
        previsao: col('Previsao'), evento: col('Dt Evento', 'Dt'), tratativa: col('Tratativa'),
      };
      if (c.codigo < 0 || c.status < 0 || c.desc < 0) throw new Error('A planilha não tem as colunas Codigo / Status / Descricao');
      const v = (l, i) => (i >= 0 && l[i] != null ? String(l[i]).trim() : '');
      dados = linhas.map(l => ({
        codigo: v(l, c.codigo), status: v(l, c.status) || VAZIO, desc: v(l, c.desc) || VAZIO, ponto: v(l, c.ponto) || VAZIO, uf: v(l, c.uf),
        cidade: v(l, c.cidade), bairro: v(l, c.bairro), rota: v(l, c.rota), circuit: v(l, c.circuit),
        previsao: v(l, c.previsao), dias: aging(v(l, c.evento)), tratativa: v(l, c.tratativa),
      })).filter(d => d.codigo);
      estado(`Pronto (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
      definirUnidade();
      carregando(null);
      desenhar();
    } catch (e) {
      console.error(e);
      carregando(null);
      estado('Erro: ' + e.message);
      $('area').innerHTML = '';
      const p = document.createElement('p'); p.className = 'resumo-topo'; p.textContent = 'Erro: ' + e.message;
      $('area').before(p);
    }
  }

  $('arquivo').addEventListener('change', ev => { const f = ev.target.files[0]; if (f) carregar(f); });
  document.addEventListener('dragover', ev => { ev.preventDefault(); document.body.classList.add('arrastando'); });
  document.addEventListener('dragleave', ev => { if (!ev.relatedTarget) document.body.classList.remove('arrastando'); });
  document.addEventListener('drop', ev => {
    ev.preventDefault(); document.body.classList.remove('arrastando');
    const f = ev.dataTransfer.files[0]; if (f) carregar(f);
  });

  /* ---------- Unidade e filial ---------- */

  let unidade = '', filial = '';
  function maisFrequente(lista) {
    const cont = new Map();
    lista.forEach(x => { if (x && x !== VAZIO) cont.set(x, (cont.get(x) || 0) + 1); });
    return [...cont.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || '';
  }
  function definirUnidade() {
    // Nossa unidade: o último ponto com mais remessas no arquivo.
    unidade = maisFrequente(dados.map(d => d.ponto));
    // Filial que abastece a unidade: a "FL ..." do mesmo estado com mais transferências.
    const ufUnid = maisFrequente(dados.filter(d => d.ponto === unidade).map(d => d.uf));
    const transf = dados.filter(d => TRANSFER.includes(d.status));
    filial = maisFrequente(transf.filter(d => /^FL\b/i.test(d.ponto) && (!ufUnid || d.uf === ufUnid)).map(d => d.ponto))
      || maisFrequente(transf.filter(d => /^FL\b/i.test(d.ponto)).map(d => d.ponto));
    $('unidade').textContent = unidade ? '📍 ' + unidade : '';
  }

  /* ---------- Tabela: linhas por status/ocorrência × dias parados ---------- */

  const chave = (linha, dia) => linha + '\u0001' + dia;
  let grupos = new Map();   // "linha␁dia" -> registros ("*" = total)
  let rotulos = new Map();  // linha -> título do cartão

  function desenhar() {
    fecharCartao();
    grupos = new Map(); rotulos = new Map();
    const add = (linha, d) => {
      for (const k of [chave(linha, d.dias == null ? '?' : d.dias), chave(linha, '*')]) { let g = grupos.get(k); if (!g) grupos.set(k, g = []); g.push(d); }
    };
    const custodia = [], demais = [], transf = [];
    dados.forEach(d => {
      if (d.ponto === unidade && d.status === 'CUSTODIA') { custodia.push(d); add('C:' + d.desc, d); add('G:CUSTODIA', d); add('TOTAL', d); }
      else if (d.ponto === unidade && DEMAIS.includes(d.status)) { demais.push(d); add('S:' + d.status, d); add('TOTAL', d); }
      else if (filial && d.ponto === filial && TRANSFER.includes(d.status)) { transf.push(d); add('T:' + d.status, d); add('G:TRANSF', d); add('TOTAL', d); }
    });
    const total = linha => (grupos.get(chave(linha, '*')) || []).length;
    const porTotal = (a, b) => total(b) - total(a) || a.localeCompare(b, 'pt-BR');

    // Linhas da tabela
    const linhas = [];
    if (custodia.length) {
      linhas.push({ id: 'G:CUSTODIA', rotulo: 'CUSTODIA', cls: 'grupo' });
      rotulos.set('G:CUSTODIA', 'CUSTODIA');
      [...new Set(custodia.map(d => 'C:' + d.desc))].sort(porTotal).forEach(id => {
        const desc = id.slice(2); linhas.push({ id, rotulo: desc === VAZIO ? '(sem ocorrência)' : desc, cls: 'sub' });
        rotulos.set(id, 'CUSTODIA · ' + (desc === VAZIO ? 'sem ocorrência' : desc));
      });
    }
    [...new Set(demais.map(d => 'S:' + d.status))].sort(porTotal).forEach(id => { linhas.push({ id, rotulo: id.slice(2), cls: 'status' }); rotulos.set(id, id.slice(2)); });
    if (transf.length) {
      linhas.push({ id: 'G:TRANSF', rotulo: 'TRANSFERÊNCIAS — ' + filial, cls: 'grupo' });
      rotulos.set('G:TRANSF', 'Transferências em ' + filial);
      TRANSFER.filter(s => total('T:' + s)).forEach(s => { linhas.push({ id: 'T:' + s, rotulo: s, cls: 'sub' }); rotulos.set('T:' + s, s + ' · ' + filial); });
    }
    linhas.push({ id: 'TOTAL', rotulo: 'Total Geral', cls: 'total-geral' });
    rotulos.set('TOTAL', 'Todas as pendências');

    // Colunas: dias parados presentes
    const base = [...custodia, ...demais, ...transf];
    const dias = [...new Set(base.map(d => d.dias == null ? '?' : d.dias))].sort((a, b) => (a === '?') - (b === '?') || a - b);

    const t = document.createElement('table');
    t.className = 'pivo';
    const thead = t.createTHead();
    const c1 = thead.insertRow();
    c1.innerHTML = `<th class="linha" rowspan="2">Pendências \\ Dias parados</th><th class="dias-titulo" colspan="${dias.length}">Dias desde o último evento</th><th class="total" rowspan="2">Total Geral</th>`;
    const c2 = thead.insertRow();
    dias.forEach(d => { const th = document.createElement('th'); th.className = 'dia'; th.textContent = d; c2.appendChild(th); });

    const corpo = t.createTBody();
    linhas.forEach(L => {
      const tr = corpo.insertRow();
      tr.className = L.cls;
      const th = document.createElement('th'); th.className = 'linha'; th.textContent = L.rotulo; th.title = L.rotulo; tr.appendChild(th);
      [...dias, '*'].forEach(dia => {
        const td = tr.insertCell(), q = (grupos.get(chave(L.id, dia)) || []).length;
        td.textContent = q ? q.toLocaleString('pt-BR') : '';
        const cls = [];
        if (dia === '*') cls.push('total');
        if (q) {
          cls.push('n'); td.dataset.l = L.id; td.dataset.d = dia;
          if (dia !== '*' && L.cls !== 'total-geral' && L.cls !== 'grupo') cls.push(dia === '?' ? '' : dia >= 7 ? 'q3' : dia >= 3 ? 'q2' : dia >= 1 ? 'q1' : '');
        }
        td.className = cls.filter(Boolean).join(' ');
      });
    });

    $('area').innerHTML = '';
    $('area').appendChild(t);
    $('fonte').textContent = `${base.length.toLocaleString('pt-BR')} pendências`;
  }

  /* ---------- Cartão com as remessas da célula ---------- */

  const cartao = $('cartao');
  $('area').addEventListener('mouseover', ev => {
    const td = ev.target.closest('td.n');
    if (!td || td === celulaAtiva) return;
    abrirCartao(td);
  });
  $('area').addEventListener('mouseout', ev => { if (ev.target.closest('td.n')) agendarFechar(); });
  cartao.addEventListener('mouseenter', () => clearTimeout(fecharTimer));
  cartao.addEventListener('mouseleave', agendarFechar);
  cartao.querySelector('.c-fechar').addEventListener('click', fecharCartao);
  document.addEventListener('keydown', ev => { if (ev.key === 'Escape') fecharCartao(); });

  function agendarFechar() { clearTimeout(fecharTimer); fecharTimer = setTimeout(fecharCartao, 350); }
  function fecharCartao() {
    clearTimeout(fecharTimer);
    cartao.hidden = true;
    if (celulaAtiva) celulaAtiva.classList.remove('ativo');
    celulaAtiva = null;
  }

  function abrirCartao(td) {
    clearTimeout(fecharTimer);
    if (celulaAtiva) celulaAtiva.classList.remove('ativo');
    celulaAtiva = td; td.classList.add('ativo');
    const l = td.dataset.l, dia = td.dataset.d;
    listaCartao = (grupos.get(chave(l, dia)) || []).slice().sort((a, b) => (b.dias ?? -1) - (a.dias ?? -1));
    const quando = dia === '*' ? 'todos os dias' : dia === '?' ? 'sem data' : `${dia} dia(s) parado(s)`;
    cartao.querySelector('.c-titulo').textContent = `${rotulos.get(l) || l} · ${quando} — ${listaCartao.length.toLocaleString('pt-BR')} remessa(s)`;
    cartao.querySelector('.c-msg').textContent = listaCartao.length > LIMITE_PESQUISA ? `A pesquisa leva as ${LIMITE_PESQUISA} primeiras.` : '';
    const lista = cartao.querySelector('.c-lista');
    lista.innerHTML = '';
    const frag = document.createDocumentFragment();
    const mostraStatus = l.startsWith('G:') || l === 'TOTAL';
    listaCartao.slice(0, LIMITE_CARTAO).forEach(d => {
      const div = document.createElement('div'); div.className = 'c-linha';
      const a = document.createElement('a');
      a.href = origem + '/FractionWeb/jad/tracking?cte=' + encodeURIComponent(d.codigo);
      a.target = '_blank'; a.rel = 'noopener'; a.textContent = d.codigo;
      const info = document.createElement('span'); info.className = 'c-info';
      info.textContent = [
        d.rota && 'Rota ' + d.rota, d.circuit && 'Circuit ' + d.circuit,
        d.previsao && 'Prev. ' + d.previsao, dia === '*' && d.dias != null && d.dias + 'd parado',
      ].filter(Boolean).join(' · ');
      const sub = document.createElement('span'); sub.className = 'c-sub';
      sub.textContent = [
        mostraStatus ? d.status + (d.status === 'CUSTODIA' && d.desc !== VAZIO ? ' / ' + d.desc : '') : '',
        [d.bairro, d.cidade].filter(Boolean).join(' - '), d.tratativa,
      ].filter(Boolean).join(' · ');
      div.append(a, info);
      if (sub.textContent) div.append(sub);
      frag.appendChild(div);
    });
    lista.appendChild(frag);
    if (listaCartao.length > LIMITE_CARTAO) {
      const mais = document.createElement('div'); mais.className = 'c-mais';
      mais.textContent = `… e mais ${(listaCartao.length - LIMITE_CARTAO).toLocaleString('pt-BR')} remessa(s).`;
      lista.appendChild(mais);
    }
    // Posição: ao lado da célula, sem sair da tela.
    cartao.hidden = false;
    const r = td.getBoundingClientRect(), w = cartao.offsetWidth, h = cartao.offsetHeight;
    let left = r.right + 8; if (left + w > innerWidth - 8) left = Math.max(8, r.left - w - 8);
    let top = Math.min(r.top - 10, innerHeight - h - 8);
    cartao.style.left = left + 'px'; cartao.style.top = Math.max(8, top) + 'px';
  }

  cartao.querySelector('.c-copiar').addEventListener('click', async () => {
    const txt = listaCartao.map(d => d.codigo).join('\n');
    try { await navigator.clipboard.writeText(txt); cartao.querySelector('.c-msg').textContent = `${listaCartao.length} código(s) copiados.`; }
    catch (e) { cartao.querySelector('.c-msg').textContent = 'Não consegui copiar.'; }
  });

  cartao.querySelector('.c-pesquisar').addEventListener('click', async () => {
    const codigos = [...new Set(listaCartao.map(d => d.codigo))].slice(0, LIMITE_PESQUISA);
    await chrome.storage.local.set({ tf_pesq_lote: { v: codigos, t: Date.now() } });
    chrome.tabs.create({ url: origem + '/FractionWeb/jad/consulta' });
  });

  /* ---------- Origem (servidor do Fraction) e arquivo vindo da extensão ---------- */

  (async () => {
    try {
      const v = await chrome.storage.local.get('tf_origem');
      if (v.tf_origem) origem = v.tf_origem;
    } catch (e) { /* usa o padrão */ }
    // Aberto como painel dentro da tela Performance de Entrega: o arquivo chega por mensagem.
    if (location.hash === '#painel') {
      document.body.classList.add('modo-painel');
      carregando('Gerando o arquivo no Fraction…');
      window.addEventListener('message', ev => {
        let ok = false;
        try { ok = /(^|\.)jadlog\.com(\.br)?$/.test(new URL(ev.origin).hostname); } catch (e) { /* origem inválida */ }
        if (!ok || !ev.data || typeof ev.data !== 'object') return;
        if (ev.data.origem) { origem = ev.data.origem; try { chrome.storage.local.set({ tf_origem: origem }); } catch (e) { /* ok */ } }
        if (ev.data.tipo === 'tf-status') { estado(ev.data.texto); carregando(ev.data.erro ? null : ev.data.texto); if (ev.data.erro) { const p = document.createElement('p'); p.className = 'resumo-topo'; p.textContent = ev.data.texto; $('area').before(p); } }
        if (ev.data.tipo === 'tf-arquivo' && ev.data.buffer) carregar(new File([ev.data.buffer], ev.data.nome || 'Performance.zip'));
      });
    }
  })();
})();
