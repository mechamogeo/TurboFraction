/*
 * TurboFraction — tela Pesquisar (/FractionWeb/jad/pesquisar)
 * Vindo do link no CPF/CNPJ da consulta da remessa: escolhe o filtro CPF/CNPJ,
 * preenche o número e clica em Processar.
 */
(() => {
  'use strict';
  let pedido = null;
  try {
    pedido = JSON.parse(localStorage.getItem('tf_pesq_cpf') || 'null');
    localStorage.removeItem('tf_pesq_cpf');
  } catch (e) { return; }
  if (!pedido || !pedido.v || Date.now() - pedido.t > 60000) return;

  function definir(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  let n = 0;
  const t = setInterval(() => {
    const campo = document.getElementById('frmPesquisa:cte');
    const botao = document.getElementById('frmPesquisa:id_enviar');
    if (!campo || !botao) { if (++n > 40) clearInterval(t); return; }
    clearInterval(t);
    // Filtro "CPF / CNPJ" (procura pelo texto do rótulo de cada opção).
    for (let i = 0; i < 40; i++) {
      const r = document.getElementById('frmPesquisa:tipo:' + i);
      if (!r) break;
      const rot = document.querySelector('label[for="frmPesquisa:tipo:' + i + '"]');
      if (rot && /cpf/i.test(rot.textContent)) { if (!r.checked) r.click(); break; }
    }
    setTimeout(() => {
      definir(campo, pedido.v);
      setTimeout(() => botao.click(), 300);
    }, 400);
  }, 250);
})();
